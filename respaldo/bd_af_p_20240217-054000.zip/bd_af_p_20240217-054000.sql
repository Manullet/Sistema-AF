-- MariaDB dump 10.19  Distrib 10.4.28-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: bd_af_p
-- ------------------------------------------------------
-- Server version	10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bitacoras`
--

DROP TABLE IF EXISTS `bitacoras`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bitacoras` (
  `Id_bitacoras` bigint(20) NOT NULL,
  `Fecha` datetime NOT NULL,
  `Tabla` varchar(255) NOT NULL,
  `Accion` varchar(255) NOT NULL,
  `Descripcion` varchar(255) NOT NULL,
  `Id_Usuario` bigint(20) NOT NULL,
  `Id_objetos` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bitacoras`
--

LOCK TABLES `bitacoras` WRITE;
/*!40000 ALTER TABLE `bitacoras` DISABLE KEYS */;
/*!40000 ALTER TABLE `bitacoras` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estado_usuario`
--

DROP TABLE IF EXISTS `estado_usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estado_usuario` (
  `id_estado` bigint(20) NOT NULL AUTO_INCREMENT,
  `Estado` varchar(40) NOT NULL,
  PRIMARY KEY (`id_estado`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estado_usuario`
--

LOCK TABLES `estado_usuario` WRITE;
/*!40000 ALTER TABLE `estado_usuario` DISABLE KEYS */;
INSERT INTO `estado_usuario` VALUES (1,'ACTIVO'),(2,'INACTIVO'),(3,'NUEVO'),(4,'BLOQUEADO ');
/*!40000 ALTER TABLE `estado_usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fichas`
--

DROP TABLE IF EXISTS `fichas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fichas` (
  `id_ficha` bigint(20) NOT NULL AUTO_INCREMENT,
  `fecha_solicitud` date DEFAULT NULL,
  `anio_solicitud` int(11) DEFAULT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `creado_por` varchar(50) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `modificado_por` varchar(50) DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('A','I') DEFAULT NULL,
  `fecha_entrevista` date DEFAULT NULL,
  `nombre_encuentrador` varchar(50) DEFAULT NULL,
  `firma_productor` varchar(100) DEFAULT NULL,
  `nombre_encuestador` varchar(50) DEFAULT NULL,
  `firma_encuestador` varchar(100) DEFAULT NULL,
  `nombre_supervisor` varchar(50) DEFAULT NULL,
  `firma_supervisor` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_ficha`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fichas`
--

LOCK TABLES `fichas` WRITE;
/*!40000 ALTER TABLE `fichas` DISABLE KEYS */;
INSERT INTO `fichas` VALUES (1,'2023-11-17',2023,'Prueba','manu','2023-11-17 20:43:05','manu','2023-12-01 04:16:28','I','2023-11-17','manu',NULL,'manu',NULL,'manu',NULL),(2,'2023-11-17',2023,'Prueba','manu','2023-11-17 20:57:36','manu','2023-12-01 04:17:22','A','2023-11-17','manu',NULL,'manu',NULL,'manu',NULL),(3,'2023-11-17',2023,'Creado','manu','2023-11-20 06:00:21','manu','2023-12-01 04:17:06','A','2023-11-17','manu',NULL,'manu',NULL,'manu',NULL),(20,'2023-12-12',2023,'prueba1','2023-12-12','2023-12-12 21:46:03',NULL,'2023-12-12 21:46:03','A','0000-00-00','Enrique',NULL,'Manuel',NULL,'Mfigue',NULL),(21,'2023-12-14',2023,'TierrasSana','2023-12-01','2023-12-12 22:14:11',NULL,'2023-12-12 22:14:11','A','0000-00-00','Francisco Morazan',NULL,'Manuel',NULL,'Mfigue',NULL),(23,'2024-02-13',0,'TierrasSana','','2023-12-13 00:05:03','Mfigue','2024-02-14 04:50:25','A','2024-02-13','asdd',NULL,'asdasd',NULL,'Mfigue',NULL);
/*!40000 ALTER TABLE `fichas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hist_contrasena`
--

DROP TABLE IF EXISTS `hist_contrasena`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hist_contrasena` (
  `Id_hist` bigint(20) NOT NULL,
  `Id_Usuario` bigint(20) NOT NULL,
  `contrasena` varchar(60) NOT NULL,
  `Creado_Por` varchar(50) NOT NULL,
  `Fecha_Creacion` datetime NOT NULL,
  `Actualizado_Por` varchar(50) DEFAULT NULL,
  `Fecha_Modificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hist_contrasena`
--

LOCK TABLES `hist_contrasena` WRITE;
/*!40000 ALTER TABLE `hist_contrasena` DISABLE KEYS */;
/*!40000 ALTER TABLE `hist_contrasena` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_permisos`
--

DROP TABLE IF EXISTS `model_permisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_permisos` (
  `Id_Permisos` bigint(20) NOT NULL,
  `Tipo_Modelo` varchar(255) NOT NULL,
  `Modelo_Id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_permisos`
--

LOCK TABLES `model_permisos` WRITE;
/*!40000 ALTER TABLE `model_permisos` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_permisos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_roles`
--

DROP TABLE IF EXISTS `model_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_roles` (
  `Rol_Id` bigint(20) NOT NULL,
  `Tipo_Modelo` varchar(255) NOT NULL,
  `Modelo_Id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_roles`
--

LOCK TABLES `model_roles` WRITE;
/*!40000 ALTER TABLE `model_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `objetos`
--

DROP TABLE IF EXISTS `objetos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `objetos` (
  `Id_objetos` bigint(20) NOT NULL AUTO_INCREMENT,
  `Objeto` varchar(255) NOT NULL,
  `Descripcion` varchar(255) NOT NULL,
  `tipo_objeto` varchar(50) NOT NULL,
  `Creado_Por` bigint(20) NOT NULL,
  `Fecha_Creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `Actualizado_Por` bigint(20) NOT NULL,
  `Fecha_Actualizacon` timestamp NOT NULL DEFAULT current_timestamp(),
  `Status` enum('ACTIVO','INACTIVO') DEFAULT NULL,
  PRIMARY KEY (`Id_objetos`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `objetos`
--

LOCK TABLES `objetos` WRITE;
/*!40000 ALTER TABLE `objetos` DISABLE KEYS */;
INSERT INTO `objetos` VALUES (1,'login','inicio de sesion','pantalla',1,'2023-10-18 12:32:23',1,'2023-10-20 12:32:23','ACTIVO'),(5,'2','Bienvenida','',1,'2023-10-28 12:10:23',1,'2023-10-28 12:10:23','ACTIVO'),(7,'Pantalla','Pantalla Usuario','',1,'2023-10-29 07:45:02',1,'2023-10-29 07:45:17','INACTIVO'),(8,'consulttor','consultor de abc','',1,'2024-02-03 04:42:32',1,'2024-02-03 04:42:32','ACTIVO');
/*!40000 ALTER TABLE `objetos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parametros`
--

DROP TABLE IF EXISTS `parametros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parametros` (
  `Id_parametros` bigint(20) NOT NULL AUTO_INCREMENT,
  `id` bigint(20) NOT NULL,
  `Parametro` varchar(255) NOT NULL,
  `Valor` varchar(255) NOT NULL,
  `Fecha_Creacion` timestamp NULL DEFAULT NULL,
  `Fecha_Actualizacion` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`Id_parametros`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parametros`
--

LOCK TABLES `parametros` WRITE;
/*!40000 ALTER TABLE `parametros` DISABLE KEYS */;
INSERT INTO `parametros` VALUES (2,1,'Intentos_Fallidos','3','2022-09-27 11:46:41','2022-09-27 11:46:41'),(3,1,'Admin_Preguntas','2','2022-10-18 03:11:00',NULL),(4,1,'Vigencia_Usuario','30','2022-10-26 08:00:00',NULL),(5,1,'Min_Contraseña','5','2022-10-26 08:00:00',NULL),(6,1,'Max_Contraseña','16','2022-10-26 08:00:00',NULL),(7,1,'Intentos_Preguntas','3','2022-10-26 08:00:00',NULL),(8,1,'Min_Usuario','5','2022-10-26 19:00:00',NULL),(12,1,'Max_Usuario','15','2022-11-22 06:39:05',NULL);
/*!40000 ALTER TABLE `parametros` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permisos`
--

DROP TABLE IF EXISTS `permisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permisos` (
  `Id_Permisos` bigint(20) NOT NULL AUTO_INCREMENT,
  `Id_rol` bigint(20) NOT NULL,
  `Id_objetos` bigint(20) NOT NULL,
  `permiso_eliminacion` varchar(10) NOT NULL,
  `permiso_actualizacion` varchar(10) NOT NULL,
  `permiso_consulta` varchar(10) NOT NULL,
  `permiso_insercion` varchar(10) NOT NULL,
  `Creado_Por` bigint(20) NOT NULL,
  `Fecha_Creacion` timestamp NULL DEFAULT NULL,
  `Actualizado_Por` bigint(20) NOT NULL,
  `Fecha_Actualizacion` timestamp NULL DEFAULT NULL,
  `Estado` enum('ACTIVO','INACTIVO','','') NOT NULL,
  PRIMARY KEY (`Id_Permisos`),
  KEY `Permisos_Objeto` (`Id_objetos`),
  KEY `Permisos_Rol` (`Id_rol`),
  CONSTRAINT `Permisos_Objeto` FOREIGN KEY (`Id_objetos`) REFERENCES `objetos` (`Id_objetos`),
  CONSTRAINT `Permisos_Rol` FOREIGN KEY (`Id_rol`) REFERENCES `roles` (`Id_rol`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permisos`
--

LOCK TABLES `permisos` WRITE;
/*!40000 ALTER TABLE `permisos` DISABLE KEYS */;
INSERT INTO `permisos` VALUES (1,1,1,'SI','SI','SI','SI',1,'2023-10-17 12:35:58',1,'2023-10-19 12:35:58','ACTIVO'),(2,2,1,'NO','SI','SI','SI',1,'2023-10-29 08:57:24',1,'2023-10-29 08:58:04','INACTIVO');
/*!40000 ALTER TABLE `permisos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `preguntas`
--

DROP TABLE IF EXISTS `preguntas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preguntas` (
  `Id_pregunta` bigint(20) NOT NULL AUTO_INCREMENT,
  `Pregunta` varchar(255) NOT NULL,
  `Creador_Por` bigint(20) NOT NULL,
  `Fecha_Creacion` timestamp NULL DEFAULT NULL,
  `Actualizado_Por` bigint(20) NOT NULL,
  `Fecha_Actualizacion` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`Id_pregunta`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `preguntas`
--

LOCK TABLES `preguntas` WRITE;
/*!40000 ALTER TABLE `preguntas` DISABLE KEYS */;
INSERT INTO `preguntas` VALUES (1,'¿Cuál es tu color favorito?',1,'2023-10-11 09:45:08',1,'2023-10-12 09:45:08'),(2,'¿que equipo es tu favorito?',1,'2023-10-29 02:14:09',1,'2023-10-29 02:14:09');
/*!40000 ALTER TABLE `preguntas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `preguntas_usuario`
--

DROP TABLE IF EXISTS `preguntas_usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preguntas_usuario` (
  `Id_Pregunta_U` bigint(20) NOT NULL AUTO_INCREMENT,
  `Id_pregunta` bigint(20) NOT NULL,
  `Id_Usuario` bigint(20) DEFAULT NULL,
  `Respuestas` varchar(100) NOT NULL,
  `Creado_Por` varchar(80) DEFAULT NULL,
  `Fecha_Creacion` datetime DEFAULT NULL,
  `Modificado_Por` varchar(80) DEFAULT NULL,
  `Fecha_Modificacion` datetime DEFAULT NULL,
  PRIMARY KEY (`Id_Pregunta_U`),
  KEY `Preguntas_idx` (`Id_pregunta`),
  KEY `Preguntas_Usuario_idx` (`Id_Usuario`),
  CONSTRAINT `Preguntas_P` FOREIGN KEY (`Id_pregunta`) REFERENCES `preguntas` (`Id_pregunta`),
  CONSTRAINT `Preguntas_U` FOREIGN KEY (`Id_Usuario`) REFERENCES `usuario` (`Id_Usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `preguntas_usuario`
--

LOCK TABLES `preguntas_usuario` WRITE;
/*!40000 ALTER TABLE `preguntas_usuario` DISABLE KEYS */;
INSERT INTO `preguntas_usuario` VALUES (1,1,1,'Rojo','1','2023-10-27 22:53:34','1','2023-10-31 22:53:34'),(2,2,1,'gato','1','2023-10-28 20:14:35','1','2023-10-31 20:14:35');
/*!40000 ALTER TABLE `preguntas_usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recuperar_clave`
--

DROP TABLE IF EXISTS `recuperar_clave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recuperar_clave` (
  `Correo` varchar(255) NOT NULL,
  `Token` varchar(255) NOT NULL,
  `Fecha_Creacion` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recuperar_clave`
--

LOCK TABLES `recuperar_clave` WRITE;
/*!40000 ALTER TABLE `recuperar_clave` DISABLE KEYS */;
/*!40000 ALTER TABLE `recuperar_clave` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `respuestas`
--

DROP TABLE IF EXISTS `respuestas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `respuestas` (
  `Id_pregunta` bigint(20) NOT NULL,
  `Id_Usuario` bigint(20) NOT NULL,
  `Respuesta` varchar(255) NOT NULL,
  `Fecha_Creacion` timestamp NULL DEFAULT NULL,
  `Fecha_Actualizacion` timestamp NULL DEFAULT NULL,
  `Id_respuesta` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `respuestas`
--

LOCK TABLES `respuestas` WRITE;
/*!40000 ALTER TABLE `respuestas` DISABLE KEYS */;
/*!40000 ALTER TABLE `respuestas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `Id_rol` bigint(20) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(255) NOT NULL,
  `Descripcion` varchar(50) NOT NULL,
  `Creado_Por` bigint(20) NOT NULL,
  `Fecha_Creacion` timestamp NULL DEFAULT NULL,
  `Actualizado_Por` bigint(20) NOT NULL,
  `Fecha_Actualizacion` timestamp NULL DEFAULT NULL,
  `STATUS` enum('ACTIVO','INACTIVO') DEFAULT NULL,
  PRIMARY KEY (`Id_rol`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'ADMINISTRADOR','ADMIN',1,'2023-10-17 12:01:16',2,'2023-10-18 12:01:16','ACTIVO'),(2,'Nuevo','Personal Nuevo',1,'2023-10-29 05:42:09',1,NULL,'ACTIVO'),(18,'nomnre','SFD',1,'2023-10-31 08:04:04',1,'2023-10-31 08:04:04','ACTIVO');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sesion`
--

DROP TABLE IF EXISTS `sesion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sesion` (
  `Id_Sesion` varchar(255) NOT NULL,
  `Usuario_Id` bigint(20) DEFAULT NULL,
  `Direccion_Ip` varchar(45) DEFAULT NULL,
  `Usuario_Agente` text DEFAULT NULL,
  `Payload` text NOT NULL,
  `Ultima_Actividad` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sesion`
--

LOCK TABLES `sesion` WRITE;
/*!40000 ALTER TABLE `sesion` DISABLE KEYS */;
/*!40000 ALTER TABLE `sesion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_aldeas`
--

DROP TABLE IF EXISTS `tbl_aldeas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_aldeas` (
  `Id_Aldea` bigint(20) NOT NULL AUTO_INCREMENT,
  `Id_Departamento` bigint(20) NOT NULL,
  `Id_Municipio` bigint(20) NOT NULL,
  `Nombre_Aldea` varchar(100) DEFAULT NULL,
  `Descripcion` varchar(255) DEFAULT NULL,
  `Estado` enum('A','I') DEFAULT NULL,
  `Creado_Por` varchar(50) NOT NULL,
  `Fecha_Creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `Modificado_Por` varchar(50) DEFAULT NULL,
  `Fecha_Modificacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`Id_Aldea`),
  KEY `fk_municipio_aldeas` (`Id_Municipio`),
  KEY `fk_departamento_aldeas` (`Id_Departamento`),
  CONSTRAINT `fk_departamento_aldeas` FOREIGN KEY (`Id_Departamento`) REFERENCES `tbl_departamentos` (`Id_Departamento`),
  CONSTRAINT `fk_municipio_aldeas` FOREIGN KEY (`Id_Municipio`) REFERENCES `tbl_municipios` (`Id_Municipio`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_aldeas`
--

LOCK TABLES `tbl_aldeas` WRITE;
/*!40000 ALTER TABLE `tbl_aldeas` DISABLE KEYS */;
INSERT INTO `tbl_aldeas` VALUES (1,1,1,'Corozal','Corozal','A','1','2023-12-07 06:36:03','1','2023-12-07 06:36:03'),(2,2,3,'Chapagua','Chapagua','A','1','2023-12-07 06:36:03','1','2023-12-07 06:36:03'),(3,3,5,'Agua Salada.','Agua Salada.','A','1','2023-12-07 06:39:51','1','2023-12-07 06:39:51'),(4,4,7,'Calzontes','Calzontes','A','1','2023-12-07 06:39:51','1','2023-12-07 06:39:51'),(5,5,9,'Artemisales','Artemisales','A','1','2023-12-07 06:44:53','1','2023-12-07 06:44:53'),(10,1,1,'prueba','32wd','A','manu','2023-12-10 04:36:19',NULL,'2023-12-10 04:36:19'),(13,20,12,'aldeafinal','final','A','Mfigue','2023-12-10 15:55:54',NULL,'2023-12-10 15:55:54');
/*!40000 ALTER TABLE `tbl_aldeas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_apoyo_actividad_externa`
--

DROP TABLE IF EXISTS `tbl_apoyo_actividad_externa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_apoyo_actividad_externa` (
  `id_apoyo_ext` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_ficha` bigint(20) DEFAULT NULL,
  `id_productor` bigint(20) DEFAULT NULL,
  `recibe_apoyo_prodagrícola` enum('S','N') DEFAULT NULL,
  `atencion_por_UAG` enum('S','N') DEFAULT NULL,
  `productos_vendidospor_pralesc` enum('S','N') DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_por` varchar(255) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `modificado_por` varchar(255) DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('A','I') DEFAULT 'A',
  PRIMARY KEY (`id_apoyo_ext`),
  KEY `fk_id_ficha_apoyo_actividad_extern` (`id_ficha`),
  KEY `fk_id_productor_apoyo_actividad_extern` (`id_productor`),
  CONSTRAINT `fk_id_ficha_apoyo_actividad_extern` FOREIGN KEY (`id_ficha`) REFERENCES `fichas` (`id_ficha`),
  CONSTRAINT `fk_id_productor_apoyo_actividad_extern` FOREIGN KEY (`id_productor`) REFERENCES `tbl_productor` (`id_productor`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_apoyo_actividad_externa`
--

LOCK TABLES `tbl_apoyo_actividad_externa` WRITE;
/*!40000 ALTER TABLE `tbl_apoyo_actividad_externa` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_apoyo_actividad_externa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_apoyos`
--

DROP TABLE IF EXISTS `tbl_apoyos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_apoyos` (
  `id_apoyo_produccion` bigint(20) NOT NULL AUTO_INCREMENT,
  `tipo_apoyo_produccion` varchar(255) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_por` varchar(255) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modificado_por` varchar(255) DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('ACTIVO','INACTIVO','','') DEFAULT NULL,
  PRIMARY KEY (`id_apoyo_produccion`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_apoyos`
--

LOCK TABLES `tbl_apoyos` WRITE;
/*!40000 ALTER TABLE `tbl_apoyos` DISABLE KEYS */;
INSERT INTO `tbl_apoyos` VALUES (1,'Bono Productor','Segun indicaciones fueron 3 manzanas haha',NULL,'2023-11-04 14:07:20',NULL,'2023-11-04 14:07:20','ACTIVO'),(2,'SalarioA','Un sueldo base1','Daniela','2023-11-05 08:59:34','Daniela','2023-11-05 08:59:34','INACTIVO');
/*!40000 ALTER TABLE `tbl_apoyos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_apoyos_produccion`
--

DROP TABLE IF EXISTS `tbl_apoyos_produccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_apoyos_produccion` (
  `id_apoyo_prod` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_ficha` bigint(20) DEFAULT NULL,
  `id_productor` bigint(20) DEFAULT NULL,
  `id_apoyo_produccion` bigint(20) NOT NULL,
  `otros_detalles` text DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_por` varchar(255) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `modificado_por` varchar(255) DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('A','I') DEFAULT 'A',
  PRIMARY KEY (`id_apoyo_prod`),
  KEY `fk_id_ficha_apoyos_produccion` (`id_ficha`),
  KEY `fk_id_productor_apoyos_produccion` (`id_productor`),
  KEY `fk_id_apoyo_produccion` (`id_apoyo_produccion`),
  CONSTRAINT `fk_id_apoyo_produccion` FOREIGN KEY (`id_apoyo_produccion`) REFERENCES `tbl_apoyos` (`id_apoyo_produccion`),
  CONSTRAINT `fk_id_ficha_apoyos_produccion` FOREIGN KEY (`id_ficha`) REFERENCES `fichas` (`id_ficha`),
  CONSTRAINT `fk_id_productor_apoyos_produccion` FOREIGN KEY (`id_productor`) REFERENCES `tbl_productor` (`id_productor`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_apoyos_produccion`
--

LOCK TABLES `tbl_apoyos_produccion` WRITE;
/*!40000 ALTER TABLE `tbl_apoyos_produccion` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_apoyos_produccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_base_organizacion`
--

DROP TABLE IF EXISTS `tbl_base_organizacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_base_organizacion` (
  `id_pertenece_organizacion` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_ficha` bigint(20) NOT NULL,
  `id_productor` bigint(20) DEFAULT NULL,
  `pertenece_a_organizacion` enum('S','N') DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_por` varchar(50) DEFAULT NULL,
  `fecha_creacion` timestamp NULL DEFAULT current_timestamp(),
  `modificado_por` varchar(50) DEFAULT NULL,
  `fecha_modificacion` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('A','I') DEFAULT 'A',
  PRIMARY KEY (`id_pertenece_organizacion`),
  KEY `fk_id_productor_base_organizacion` (`id_productor`),
  KEY `fk_id_ficha_base_organizacion` (`id_ficha`),
  CONSTRAINT `fk_id_ficha_base_organizacion` FOREIGN KEY (`id_ficha`) REFERENCES `fichas` (`id_ficha`),
  CONSTRAINT `fk_id_productor_base_organizacion` FOREIGN KEY (`id_productor`) REFERENCES `tbl_productor` (`id_productor`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_base_organizacion`
--

LOCK TABLES `tbl_base_organizacion` WRITE;
/*!40000 ALTER TABLE `tbl_base_organizacion` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_base_organizacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_cacerios`
--

DROP TABLE IF EXISTS `tbl_cacerios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_cacerios` (
  `Id_Cacerio` bigint(20) NOT NULL AUTO_INCREMENT,
  `Id_Aldea` bigint(20) NOT NULL,
  `Id_Municipio` bigint(20) NOT NULL,
  `Id_Departamento` bigint(20) NOT NULL,
  `Nombre_Cacerio` varchar(100) DEFAULT NULL,
  `Descripcion` varchar(255) DEFAULT NULL,
  `Estado` enum('A','I') DEFAULT NULL,
  `Creado_Por` varchar(25) NOT NULL,
  `Fecha_Creacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Modificado_Por` varchar(25) DEFAULT NULL,
  `Fecha_Modificacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`Id_Cacerio`),
  KEY `fk_aldea_cacerios` (`Id_Aldea`),
  KEY `fk_municipio_cacerios` (`Id_Municipio`),
  KEY `fk_departamento_cacerios` (`Id_Departamento`),
  CONSTRAINT `fk_aldea_cacerios` FOREIGN KEY (`Id_Aldea`) REFERENCES `tbl_aldeas` (`Id_Aldea`),
  CONSTRAINT `fk_departamento_cacerios` FOREIGN KEY (`Id_Departamento`) REFERENCES `tbl_departamentos` (`Id_Departamento`),
  CONSTRAINT `fk_municipio_cacerios` FOREIGN KEY (`Id_Municipio`) REFERENCES `tbl_municipios` (`Id_Municipio`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_cacerios`
--

LOCK TABLES `tbl_cacerios` WRITE;
/*!40000 ALTER TABLE `tbl_cacerios` DISABLE KEYS */;
INSERT INTO `tbl_cacerios` VALUES (1,1,1,1,'cacerio 1','cacerio 1','A','1','2023-12-07 06:45:39','1','2023-12-07 06:45:39'),(2,2,3,2,'cacerio 2','cacerio 2','A','1','2023-12-07 06:47:43','1','2023-12-07 06:47:43'),(3,3,5,3,'caserio 3','caserio 3','A','1','2023-12-07 06:49:40','1','2023-12-07 06:49:40'),(4,4,7,4,'caserio 4','caserio 4','A','1','2023-12-07 06:51:00','1','2023-12-07 06:51:00'),(5,5,9,5,'caserio 5','caserio 5','A','1','2023-12-07 06:51:51','1','2023-12-07 06:51:51'),(9,13,12,20,'caseriofinal','final','A','Mfigue','2023-12-10 15:56:16',NULL,'2023-12-10 15:56:16');
/*!40000 ALTER TABLE `tbl_cacerios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_composicion`
--

DROP TABLE IF EXISTS `tbl_composicion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_composicion` (
  `id_ficha` bigint(20) DEFAULT NULL,
  `id_composicion` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_productor` bigint(20) DEFAULT NULL,
  `genero` enum('H','M') DEFAULT NULL,
  `edad` int(11) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_por` varchar(25) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `modificado_por` varchar(25) DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('A','I') DEFAULT NULL,
  PRIMARY KEY (`id_composicion`),
  KEY `fk_id_ficha_composicion` (`id_ficha`),
  KEY `fk_id_producto_composicionr` (`id_productor`),
  CONSTRAINT `fk_id_ficha_composicion` FOREIGN KEY (`id_ficha`) REFERENCES `fichas` (`id_ficha`),
  CONSTRAINT `fk_id_producto_composicionr` FOREIGN KEY (`id_productor`) REFERENCES `tbl_productor` (`id_productor`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_composicion`
--

LOCK TABLES `tbl_composicion` WRITE;
/*!40000 ALTER TABLE `tbl_composicion` DISABLE KEYS */;
INSERT INTO `tbl_composicion` VALUES (1,1,1,'H',28,'eff','manu','2023-12-10 00:35:11','manu','2023-12-10 00:35:11','A');
/*!40000 ALTER TABLE `tbl_composicion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_credito_produccion`
--

DROP TABLE IF EXISTS `tbl_credito_produccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_credito_produccion` (
  `id_credpro` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_ficha` bigint(20) DEFAULT NULL,
  `id_productor` bigint(20) DEFAULT NULL,
  `ha_solicitado_creditos` enum('S','N') DEFAULT NULL,
  `id_fuente_credito` bigint(20) DEFAULT NULL,
  `monto_credito` decimal(10,2) DEFAULT NULL,
  `id_motivos_no_credito` bigint(20) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_por` varchar(255) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `modificado_por` varchar(255) DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('A','I') DEFAULT 'A',
  PRIMARY KEY (`id_credpro`),
  KEY `fk_id_fuente_credito` (`id_fuente_credito`),
  KEY `fk_id_ficha_credito_produccion` (`id_ficha`),
  KEY `fk_id_productor_credito_produccion` (`id_productor`),
  KEY `fk_id_motivos_no_credito` (`id_motivos_no_credito`),
  CONSTRAINT `fk_id_ficha_credito_produccion` FOREIGN KEY (`id_ficha`) REFERENCES `fichas` (`id_ficha`),
  CONSTRAINT `fk_id_fuente_credito` FOREIGN KEY (`id_fuente_credito`) REFERENCES `tbl_fuentes_credito` (`id_fuente_credito`),
  CONSTRAINT `fk_id_motivos_no_credito` FOREIGN KEY (`id_motivos_no_credito`) REFERENCES `tbl_motivos_no_creditos` (`id_motivos_no_credito`),
  CONSTRAINT `fk_id_productor_credito_produccion` FOREIGN KEY (`id_productor`) REFERENCES `tbl_productor` (`id_productor`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_credito_produccion`
--

LOCK TABLES `tbl_credito_produccion` WRITE;
/*!40000 ALTER TABLE `tbl_credito_produccion` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_credito_produccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_departamentos`
--

DROP TABLE IF EXISTS `tbl_departamentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_departamentos` (
  `Id_Departamento` bigint(20) NOT NULL AUTO_INCREMENT,
  `Nombre_Departamento` varchar(100) DEFAULT NULL,
  `Descripcion` varchar(255) DEFAULT NULL,
  `Creado_Por` varchar(25) NOT NULL,
  `Fecha_Creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `Modificado_Por` varchar(25) DEFAULT NULL,
  `Fecha_Modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Estado` enum('A','I') DEFAULT NULL,
  PRIMARY KEY (`Id_Departamento`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_departamentos`
--

LOCK TABLES `tbl_departamentos` WRITE;
/*!40000 ALTER TABLE `tbl_departamentos` DISABLE KEYS */;
INSERT INTO `tbl_departamentos` VALUES (1,'Atlántida','Atlántida','1','2023-12-07 05:54:18','1','2023-12-07 05:54:18','A'),(2,'Colón','Colón','1','2023-12-07 05:55:56','1','2023-12-07 05:55:56','A'),(3,'Comayagua','Comayagua','1','2023-12-07 05:55:56','1','2023-12-07 05:55:56','A'),(4,'Copán','Copán','1','2023-12-07 05:57:00','1','2023-12-07 05:57:00','A'),(5,'Cortés','Cortés','1','2023-12-07 06:01:28','1','2023-12-07 06:01:28','A'),(6,'Choluteca','Choluteca','1','2023-12-07 05:57:00','1','2023-12-07 05:57:00','A'),(7,'El Paraíso','El Paraíso','1','2023-12-07 06:01:57','1','2023-12-07 06:01:57','A'),(8,'Francisco Morazán','Francisco Morazán','1','2023-12-07 06:01:57','1','2023-12-07 06:01:57','A'),(9,'Gracias a Dios','Gracias a Dios','1','2023-12-07 06:02:45','1','2023-12-07 06:02:45','A'),(10,'Intibucá','Intibucá','1','2023-12-07 06:03:16','1','2023-12-07 06:03:16','A'),(11,'Islas de la Bahía','Islas de la Bahía','1','2023-12-07 06:03:33','1','2023-12-07 06:03:33','A'),(12,'La Paz','La Paz','1','2023-12-07 06:03:55','1','2023-12-07 06:03:55','A'),(13,'Lempira','Lempira','1','2023-12-07 06:03:55','1','2023-12-07 06:03:55','A'),(14,'Ocotepeque','Ocotepeque','1','2023-12-07 06:04:32','1','2023-12-07 06:04:32','A'),(15,'Olancho','Olancho','1','2023-12-07 06:04:49','1','2023-12-07 06:04:49','A'),(16,'Santa Bárbara','Santa Bárbara','1','2023-12-07 06:05:06','1','2023-12-07 06:05:06','A'),(17,'Valle','Valle','1','2023-12-07 06:05:22','1','2023-12-07 06:05:22','A'),(18,'Yoro','Yoro','1','2023-12-07 06:05:39','manu','2023-12-09 21:32:00','A'),(20,'DepFinal','desc','Mfigue','2023-12-10 15:53:57',NULL,'2023-12-10 15:53:57','A');
/*!40000 ALTER TABLE `tbl_departamentos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_etnias`
--

DROP TABLE IF EXISTS `tbl_etnias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_etnias` (
  `id_etnia` bigint(11) NOT NULL AUTO_INCREMENT,
  `etnia` varchar(255) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_por` varchar(255) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modificado_por` varchar(255) DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('A','I') NOT NULL DEFAULT 'A',
  PRIMARY KEY (`id_etnia`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_etnias`
--

LOCK TABLES `tbl_etnias` WRITE;
/*!40000 ALTER TABLE `tbl_etnias` DISABLE KEYS */;
INSERT INTO `tbl_etnias` VALUES (1,'Lenca','Prueba','Usuario1','2023-12-11 20:37:01','Usuario1','2023-12-11 20:37:01','A'),(2,'Pech','Descripción de Etnia 2','Usuario2','2023-12-11 20:40:44','Usuario2','2023-12-11 20:40:44','A'),(3,'Tolupanes','Descripción de Etnia 3','Usuario3','2023-12-11 20:41:13','Usuario3','2023-12-11 20:41:13','A'),(4,'Garífunas','Descripción de Etnia 4','Usuario4','2023-12-11 20:38:19','Usuario4','2023-12-11 20:38:19','A'),(5,'Maya Chortís','Descripción de Etnia 5','Usuario5','2023-12-11 20:41:19','Usuario5','2023-12-11 20:41:19','A'),(6,'Tawahkas','Descripción de Etnia 6','Usuario6','2023-12-11 20:38:42','Usuario6','2023-12-11 20:38:42','A'),(7,'Misquitos','Descripción de Etnia 7','Usuario7','2023-12-11 20:38:52','Usuario7','2023-12-11 20:38:52','A'),(8,'Nahua','Descripción de Etnia 8','Usuario8','2023-12-11 20:41:25','Usuario8','2023-12-11 20:41:25','A'),(9,'Ladino','Descripción de Etnia 9','Usuario9','2023-12-11 20:39:08','Usuario9','2023-12-11 20:39:08','A'),(10,'Negro habla inglesa','Descripción de Etnia 10','Usuario10','2023-12-11 20:41:33','Usuario10','2023-12-11 20:41:33','A'),(11,'Otros(Especifique)','Descripción de Etnia 11','Usuario11','2023-12-11 20:41:38','Usuario11','2023-12-11 20:41:38','A');
/*!40000 ALTER TABLE `tbl_etnias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_etnias_por_productor`
--

DROP TABLE IF EXISTS `tbl_etnias_por_productor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_etnias_por_productor` (
  `Id_etnicidad` bigint(11) NOT NULL AUTO_INCREMENT,
  `id_ficha` bigint(20) DEFAULT NULL,
  `id_productor` bigint(20) DEFAULT NULL,
  `id_etnia` bigint(20) NOT NULL,
  `detalle_de_otros` varchar(255) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_por` varchar(50) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `modificado_por` varchar(50) DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('A','I') DEFAULT 'A',
  PRIMARY KEY (`Id_etnicidad`),
  KEY `id_productor` (`id_productor`),
  KEY `id_etnia` (`id_etnia`),
  KEY `fk_etnias_fichas` (`id_ficha`),
  CONSTRAINT `fk_etnias_fichas` FOREIGN KEY (`id_ficha`) REFERENCES `fichas` (`id_ficha`),
  CONSTRAINT `tbl_etnias_por_productor_ibfk_1` FOREIGN KEY (`id_productor`) REFERENCES `tbl_productor` (`id_productor`),
  CONSTRAINT `tbl_etnias_por_productor_ibfk_2` FOREIGN KEY (`id_etnia`) REFERENCES `tbl_etnias` (`id_etnia`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_etnias_por_productor`
--

LOCK TABLES `tbl_etnias_por_productor` WRITE;
/*!40000 ALTER TABLE `tbl_etnias_por_productor` DISABLE KEYS */;
INSERT INTO `tbl_etnias_por_productor` VALUES (20,20,20,5,NULL,NULL,'Mfigue','2023-12-12 21:47:58',NULL,'2023-12-12 21:47:58','A');
/*!40000 ALTER TABLE `tbl_etnias_por_productor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_fuentes_credito`
--

DROP TABLE IF EXISTS `tbl_fuentes_credito`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_fuentes_credito` (
  `id_fuente_credito` bigint(20) NOT NULL AUTO_INCREMENT,
  `fuente_credito` varchar(255) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_por` varchar(255) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modificado_por` varchar(255) DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('A','I') DEFAULT NULL,
  PRIMARY KEY (`id_fuente_credito`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_fuentes_credito`
--

LOCK TABLES `tbl_fuentes_credito` WRITE;
/*!40000 ALTER TABLE `tbl_fuentes_credito` DISABLE KEYS */;
INSERT INTO `tbl_fuentes_credito` VALUES (1,'Banca','Bancos','usuario1','2023-12-11 10:25:53','usuario1','2023-12-11 10:25:53','A'),(2,'Amigos','Amigos cercanos','usuario1','2023-12-11 10:26:08','usuario1','2023-12-11 10:26:08','A'),(3,'Familia','Familiares','usuario1','2023-12-11 10:26:24','usuario1','2023-12-11 10:26:24','A'),(4,'Cooperativa','Cooperativas','usuario1','2023-12-11 10:27:00','usuario1','2023-12-11 10:27:00','A'),(5,'Prestamistas','Prestamistas','usuario1','2023-12-11 10:27:19','usuario1','2023-12-11 10:27:19','A'),(6,'Microfinanciera','Microfinanciera','usuario1','2023-12-11 10:27:40','usuario1','2023-12-11 10:27:40','A'),(7,'Caja rural','Caja rural','usuario1','2023-12-11 10:27:58','usuario1','2023-12-11 10:27:58','A');
/*!40000 ALTER TABLE `tbl_fuentes_credito` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_ingreso_familiar`
--

DROP TABLE IF EXISTS `tbl_ingreso_familiar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_ingreso_familiar` (
  `Id_Ficha` bigint(20) DEFAULT NULL,
  `Id_Productor` bigint(20) DEFAULT NULL,
  `Id_Ingreso_Familiar` bigint(20) NOT NULL AUTO_INCREMENT,
  `Id_Tipo_Negocio` bigint(20) DEFAULT NULL,
  `Total_Ingreso` decimal(10,2) DEFAULT NULL,
  `Id_Periodo_Ingreso` bigint(20) DEFAULT NULL,
  `Descripcion_Otros` varchar(255) DEFAULT NULL,
  `Descripcion` varchar(255) DEFAULT NULL,
  `Creado_Por` varchar(255) DEFAULT NULL,
  `Fecha_Creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `Modificado_Por` varchar(255) DEFAULT NULL,
  `Fecha_Modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('A','I') DEFAULT 'A',
  PRIMARY KEY (`Id_Ingreso_Familiar`),
  KEY `FK_Id_Productor_Ingreso_Familiar` (`Id_Productor`),
  KEY `FK_Id_Tipo_Negocio_Ingreso_Familiar` (`Id_Tipo_Negocio`),
  KEY `FK_Id_Periodo_Ingreso_Ingreso_Familiar` (`Id_Periodo_Ingreso`),
  KEY `FK_Id_Ficha_Ingreso_Familiar` (`Id_Ficha`),
  CONSTRAINT `FK_Id_Ficha_Ingreso_Familiar` FOREIGN KEY (`Id_Ficha`) REFERENCES `fichas` (`id_ficha`),
  CONSTRAINT `FK_Id_Periodo_Ingreso_Ingreso_Familiar` FOREIGN KEY (`Id_Periodo_Ingreso`) REFERENCES `tbl_periodicidad` (`id_periodo`),
  CONSTRAINT `FK_Id_Productor_Ingreso_Familiar` FOREIGN KEY (`Id_Productor`) REFERENCES `tbl_productor` (`id_productor`),
  CONSTRAINT `FK_Id_Tipo_Negocio_Ingreso_Familiar` FOREIGN KEY (`Id_Tipo_Negocio`) REFERENCES `tbl_tipo_negocios` (`id_tipo_negocio`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_ingreso_familiar`
--

LOCK TABLES `tbl_ingreso_familiar` WRITE;
/*!40000 ALTER TABLE `tbl_ingreso_familiar` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_ingreso_familiar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_manejo_riego`
--

DROP TABLE IF EXISTS `tbl_manejo_riego`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_manejo_riego` (
  `Id_Manejo_Riego` bigint(20) NOT NULL AUTO_INCREMENT,
  `Id_Ficha` bigint(20) DEFAULT NULL,
  `Id_Ubicacion` bigint(20) DEFAULT NULL,
  `Id_Productor` bigint(20) DEFAULT NULL,
  `Tiene_Riego` enum('S','N') DEFAULT NULL,
  `Superficie_Riego` decimal(10,2) DEFAULT NULL,
  `Id_Medida_Superficie_Riego` bigint(20) DEFAULT NULL,
  `Id_Tipo_Riego` bigint(20) DEFAULT NULL,
  `Fuente_Agua` varchar(255) DEFAULT NULL,
  `Disponibilidad_Agua_Meses` int(11) DEFAULT NULL,
  `Descripcion` varchar(255) DEFAULT NULL,
  `Id_Usuario` bigint(20) DEFAULT NULL,
  `Creado_Por` varchar(255) DEFAULT NULL,
  `Fecha_Creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `Modificado_Por` varchar(255) DEFAULT NULL,
  `Fecha_Modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Estado` enum('A','I') DEFAULT 'A',
  PRIMARY KEY (`Id_Manejo_Riego`),
  KEY `FK_Id_Ficha_Manejo_Riego` (`Id_Ficha`),
  KEY `FK_Id_Ubicacion_Manejo_Riego` (`Id_Ubicacion`),
  KEY `FK_Id_Productor_Manejo_Riego` (`Id_Productor`),
  KEY `FK_Id_Medida_Superficie_Riego` (`Id_Medida_Superficie_Riego`),
  KEY `FK_Id_Tipo_Riego` (`Id_Tipo_Riego`),
  CONSTRAINT `FK_Id_Ficha_Manejo_Riego` FOREIGN KEY (`Id_Ficha`) REFERENCES `fichas` (`id_ficha`),
  CONSTRAINT `FK_Id_Medida_Superficie_Riego` FOREIGN KEY (`Id_Medida_Superficie_Riego`) REFERENCES `tbl_medidas_tierra` (`id_medida`),
  CONSTRAINT `FK_Id_Productor_Manejo_Riego` FOREIGN KEY (`Id_Productor`) REFERENCES `tbl_productor` (`id_productor`),
  CONSTRAINT `FK_Id_Tipo_Riego` FOREIGN KEY (`Id_Tipo_Riego`) REFERENCES `tbl_tipo_riego` (`id_tipo_riego`),
  CONSTRAINT `FK_Id_Ubicacion_Manejo_Riego` FOREIGN KEY (`Id_Ubicacion`) REFERENCES `tbl_ubicacion_productor` (`id_ubicacion`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_manejo_riego`
--

LOCK TABLES `tbl_manejo_riego` WRITE;
/*!40000 ALTER TABLE `tbl_manejo_riego` DISABLE KEYS */;
INSERT INTO `tbl_manejo_riego` VALUES (4,21,46,21,'S',10.00,3,1,'pozo comunitario',1,NULL,NULL,'manu','2023-12-12 22:19:38',NULL,'2023-12-12 22:19:38','A');
/*!40000 ALTER TABLE `tbl_manejo_riego` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_medidas_tierra`
--

DROP TABLE IF EXISTS `tbl_medidas_tierra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_medidas_tierra` (
  `id_medida` bigint(20) NOT NULL AUTO_INCREMENT,
  `medida` varchar(25) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_por` varchar(255) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modificado_por` varchar(255) DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('ACTIVO','INACTIVO','','') DEFAULT NULL,
  PRIMARY KEY (`id_medida`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_medidas_tierra`
--

LOCK TABLES `tbl_medidas_tierra` WRITE;
/*!40000 ALTER TABLE `tbl_medidas_tierra` DISABLE KEYS */;
INSERT INTO `tbl_medidas_tierra` VALUES (1,'TAREAS','Son 5 tareas',NULL,'2023-11-04 14:08:58',NULL,'2023-11-04 14:08:58','ACTIVO'),(2,'HA','Se compraron 2','Daniela','2023-11-05 08:59:02','Daniela','2023-11-05 08:59:02','INACTIVO'),(3,'MZ','desc','Daniela','2023-12-11 01:56:55','Daniela','2023-12-11 01:56:55','ACTIVO'),(4,'CM','CM (Centimetro)','manu','2023-12-11 01:57:01','manu','2023-12-11 01:57:01','ACTIVO');
/*!40000 ALTER TABLE `tbl_medidas_tierra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_migracion_familiar`
--

DROP TABLE IF EXISTS `tbl_migracion_familiar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_migracion_familiar` (
  `id_ficha` bigint(20) DEFAULT NULL,
  `id_productor` bigint(20) DEFAULT NULL,
  `id_migracion` bigint(20) NOT NULL AUTO_INCREMENT,
  `tiene_migrantes` enum('S','N') DEFAULT NULL,
  `migracion_dentro_pais` enum('S','N') DEFAULT NULL,
  `migracion_fuera_pais` enum('S','N') DEFAULT NULL,
  `id_tipo_motivos` bigint(20) NOT NULL,
  `remesas` enum('S','N') DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_por` varchar(50) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `modificado_por` varchar(50) DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('A','I') DEFAULT NULL,
  PRIMARY KEY (`id_migracion`),
  KEY `fk_id_ficha_migracion_familiar` (`id_ficha`),
  KEY `fk_id_productor_migracion_familiar` (`id_productor`),
  KEY `fk_id_tipo_motivos` (`id_tipo_motivos`),
  CONSTRAINT `fk_id_ficha_migracion_familiar` FOREIGN KEY (`id_ficha`) REFERENCES `fichas` (`id_ficha`),
  CONSTRAINT `fk_id_productor_migracion_familiar` FOREIGN KEY (`id_productor`) REFERENCES `tbl_productor` (`id_productor`),
  CONSTRAINT `fk_id_tipo_motivos` FOREIGN KEY (`id_tipo_motivos`) REFERENCES `tbl_motivos_migracion` (`Id_motivo`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_migracion_familiar`
--

LOCK TABLES `tbl_migracion_familiar` WRITE;
/*!40000 ALTER TABLE `tbl_migracion_familiar` DISABLE KEYS */;
INSERT INTO `tbl_migracion_familiar` VALUES (20,20,20,'S','S','N',1,'S',NULL,'Mfigue','2023-12-12 21:48:14',NULL,'2023-12-12 21:48:14','A');
/*!40000 ALTER TABLE `tbl_migracion_familiar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_motivos_migracion`
--

DROP TABLE IF EXISTS `tbl_motivos_migracion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_motivos_migracion` (
  `Id_motivo` bigint(20) NOT NULL AUTO_INCREMENT,
  `Motivo` varchar(255) DEFAULT NULL,
  `Descripcion` text DEFAULT NULL,
  `Creado_por` varchar(255) DEFAULT NULL,
  `Fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `Modificado_por` varchar(255) DEFAULT NULL,
  `Fecha_Actualizacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Estado` enum('A','I') NOT NULL DEFAULT 'A',
  PRIMARY KEY (`Id_motivo`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_motivos_migracion`
--

LOCK TABLES `tbl_motivos_migracion` WRITE;
/*!40000 ALTER TABLE `tbl_motivos_migracion` DISABLE KEYS */;
INSERT INTO `tbl_motivos_migracion` VALUES (1,'Estudio','por el Estudio','Manuel','2023-10-31 03:56:32','Manuel','2023-12-11 23:07:04','A'),(2,'Trabajo','No encuentra Trabajo en el país.','manuel','2023-10-31 04:58:55','manuel','2023-12-11 23:08:12','A'),(3,'Violencia','Violencia familiar o amenazas','Manuel','2023-10-31 05:07:18','Manuel','2023-12-11 23:09:08','A'),(4,'Cambio climático','Cambio climático o desastre natural','Manuel','2023-10-31 05:15:26','Manuel','2023-12-11 23:09:56','A');
/*!40000 ALTER TABLE `tbl_motivos_migracion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_motivos_no_creditos`
--

DROP TABLE IF EXISTS `tbl_motivos_no_creditos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_motivos_no_creditos` (
  `id_motivos_no_credito` bigint(20) NOT NULL AUTO_INCREMENT,
  `motivo_no_credito` varchar(255) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_por` varchar(255) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `modificado_por` varchar(255) DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('A','I') DEFAULT NULL,
  PRIMARY KEY (`id_motivos_no_credito`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_motivos_no_creditos`
--

LOCK TABLES `tbl_motivos_no_creditos` WRITE;
/*!40000 ALTER TABLE `tbl_motivos_no_creditos` DISABLE KEYS */;
INSERT INTO `tbl_motivos_no_creditos` VALUES (4,'Estoy en la central de riesgos','Estoy en la central de riesgos','admin','2023-12-11 12:03:51',NULL,'2023-12-11 12:03:51','A'),(5,'Muchos requisitos','Son muchos los requisitos','admin','2023-12-11 12:03:51',NULL,'2023-12-11 12:04:30','A'),(6,'No lo he necesitado','No lo he necesitado','admin','2023-12-11 12:03:51',NULL,'2023-12-11 12:03:51','A'),(7,'No tengo capacidad de pago','No tengo capacidad de pago','admin','2023-12-11 12:03:51',NULL,'2023-12-11 12:03:51','A'),(8,'Temor al rechazo','Temor al rechazo','admin','2023-12-11 12:03:51',NULL,'2023-12-11 12:03:51','A'),(9,'Temor a no pagarlo','Temor a no pagarlo','admin','2023-12-11 12:03:51',NULL,'2023-12-11 12:03:51','A'),(10,'Tasas de interés muy altas','Tasas de interés muy altas','admin','2023-12-11 12:03:51',NULL,'2023-12-11 12:03:51','A'),(11,'Prueba','Prueba','manu','2023-12-11 12:07:40',NULL,'2023-12-11 12:07:40','A');
/*!40000 ALTER TABLE `tbl_motivos_no_creditos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_municipios`
--

DROP TABLE IF EXISTS `tbl_municipios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_municipios` (
  `Id_Municipio` bigint(20) NOT NULL AUTO_INCREMENT,
  `Id_Departamento` bigint(20) NOT NULL,
  `Nombre_Municipio` varchar(100) DEFAULT NULL,
  `Descripcion` varchar(255) DEFAULT NULL,
  `Creado_Por` varchar(25) NOT NULL,
  `Fecha_Creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `Modificado_Por` varchar(25) DEFAULT NULL,
  `Fecha_Modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Estado` enum('A','I') DEFAULT 'A',
  PRIMARY KEY (`Id_Municipio`),
  KEY `fk_municipios_departamento` (`Id_Departamento`),
  CONSTRAINT `fk_municipios_departamento` FOREIGN KEY (`Id_Departamento`) REFERENCES `tbl_departamentos` (`Id_Departamento`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_municipios`
--

LOCK TABLES `tbl_municipios` WRITE;
/*!40000 ALTER TABLE `tbl_municipios` DISABLE KEYS */;
INSERT INTO `tbl_municipios` VALUES (1,1,'La Ceiba','La Ceiba','1','2023-12-07 06:26:42','1','2023-12-07 06:26:42','A'),(2,1,'El Porvenir','El Porvenir','1','2023-12-07 06:26:42','1','2023-12-07 06:26:42','A'),(3,2,'Trujillo','Trujillo','1','2023-12-07 06:28:16','1','2023-12-07 06:28:16','A'),(4,2,'Balfate','Balfate','1','2023-12-07 06:29:48','1','2023-12-07 06:29:48','A'),(5,3,'Comayagua','Comayagua','1','2023-12-07 06:30:29','1','2023-12-07 06:30:29','A'),(6,3,'Ajuterique','Ajuterique','1','2023-12-07 06:31:37','1','2023-12-07 06:31:37','A'),(7,4,'Santa Rosa de Copán','Santa Rosa de Copán','1','2023-12-07 06:32:16','1','2023-12-07 06:32:16','A'),(8,4,'Cabañas','Cabañas','1','2023-12-07 06:33:12','1','2023-12-07 06:33:12','A'),(9,5,'San Pedro Sula','San Pedro Sula','1','2023-12-07 06:33:54','1','2023-12-07 06:33:54','A'),(10,5,'Choloma','Choloma','1','2023-12-07 06:34:21','1','2023-12-07 06:34:21','A'),(12,20,'Munifinal','final','Mfigue','2023-12-10 15:54:22',NULL,'2023-12-10 15:54:22','A');
/*!40000 ALTER TABLE `tbl_municipios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_no_creditos`
--

DROP TABLE IF EXISTS `tbl_no_creditos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_no_creditos` (
  `id_nocred` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_ficha` bigint(20) DEFAULT NULL,
  `id_productor` bigint(20) DEFAULT NULL,
  `id_motivos_no_credito` bigint(20) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_por` varchar(255) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `modificado_por` varchar(255) DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('A','I') DEFAULT 'A',
  PRIMARY KEY (`id_nocred`),
  KEY `fk_id_fichal_no_creditos` (`id_ficha`),
  KEY `fk_id_productorl_no_creditos` (`id_productor`),
  KEY `fk_id_motivos_no_credito1` (`id_motivos_no_credito`),
  CONSTRAINT `fk_id_fichal_no_creditos` FOREIGN KEY (`id_ficha`) REFERENCES `fichas` (`id_ficha`),
  CONSTRAINT `fk_id_motivos_no_credito1` FOREIGN KEY (`id_motivos_no_credito`) REFERENCES `tbl_motivos_no_creditos` (`id_motivos_no_credito`),
  CONSTRAINT `fk_id_productorl_no_creditos` FOREIGN KEY (`id_productor`) REFERENCES `tbl_productor` (`id_productor`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_no_creditos`
--

LOCK TABLES `tbl_no_creditos` WRITE;
/*!40000 ALTER TABLE `tbl_no_creditos` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_no_creditos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_organizaciones`
--

DROP TABLE IF EXISTS `tbl_organizaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_organizaciones` (
  `id_organizacion` bigint(20) NOT NULL AUTO_INCREMENT,
  `organizacion` varchar(255) DEFAULT NULL,
  `id_tipo_organizacion` bigint(20) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_por` varchar(255) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `modificado_por` varchar(255) DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('A','I') DEFAULT NULL,
  PRIMARY KEY (`id_organizacion`),
  KEY `fk_tipo_organizacion` (`id_tipo_organizacion`),
  CONSTRAINT `fk_tipo_organizacion` FOREIGN KEY (`id_tipo_organizacion`) REFERENCES `tbl_tipo_organizacion` (`id_tipo_organizacion`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_organizaciones`
--

LOCK TABLES `tbl_organizaciones` WRITE;
/*!40000 ALTER TABLE `tbl_organizaciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_organizaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_organizaciones_por_productor`
--

DROP TABLE IF EXISTS `tbl_organizaciones_por_productor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_organizaciones_por_productor` (
  `id_ficha` bigint(20) DEFAULT NULL,
  `id_productor` bigint(20) DEFAULT NULL,
  `id_organizacion` bigint(20) NOT NULL,
  `Id_Organizacion_Productor` bigint(20) NOT NULL AUTO_INCREMENT,
  `descripcion` text DEFAULT NULL,
  `creado_por` varchar(50) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `modificado_por` varchar(50) DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('A','I') DEFAULT 'A',
  PRIMARY KEY (`Id_Organizacion_Productor`),
  KEY `fk_organizacion_por_productor` (`id_organizacion`),
  KEY `fk_id_productor` (`id_productor`),
  KEY `id_ficha` (`id_ficha`),
  CONSTRAINT `fk_id_productor` FOREIGN KEY (`id_productor`) REFERENCES `tbl_productor` (`id_productor`),
  CONSTRAINT `fk_organizacion_por_productor` FOREIGN KEY (`id_organizacion`) REFERENCES `tbl_organizaciones` (`id_organizacion`),
  CONSTRAINT `tbl_organizaciones_por_productor_ibfk_1` FOREIGN KEY (`id_ficha`) REFERENCES `fichas` (`id_ficha`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_organizaciones_por_productor`
--

LOCK TABLES `tbl_organizaciones_por_productor` WRITE;
/*!40000 ALTER TABLE `tbl_organizaciones_por_productor` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_organizaciones_por_productor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_parametros`
--

DROP TABLE IF EXISTS `tbl_parametros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_parametros` (
  `id_parametros` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_usuario` bigint(20) NOT NULL,
  `parametro` varchar(30) NOT NULL,
  `valor` varchar(20) NOT NULL,
  `Fecha_Creacion` datetime NOT NULL,
  `Fecha_Modificacion` datetime DEFAULT NULL,
  PRIMARY KEY (`id_parametros`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_parametros`
--

LOCK TABLES `tbl_parametros` WRITE;
/*!40000 ALTER TABLE `tbl_parametros` DISABLE KEYS */;
INSERT INTO `tbl_parametros` VALUES (1,1,'admin_dias_vigencia','360','2023-12-09 23:48:41','2023-12-08 23:48:41');
/*!40000 ALTER TABLE `tbl_parametros` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_periodicidad`
--

DROP TABLE IF EXISTS `tbl_periodicidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_periodicidad` (
  `id_periodo` bigint(20) NOT NULL AUTO_INCREMENT,
  `periodo` varchar(255) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_por` varchar(255) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `modificado_por` varchar(255) DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('A','I') DEFAULT NULL,
  PRIMARY KEY (`id_periodo`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_periodicidad`
--

LOCK TABLES `tbl_periodicidad` WRITE;
/*!40000 ALTER TABLE `tbl_periodicidad` DISABLE KEYS */;
INSERT INTO `tbl_periodicidad` VALUES (1,'bimestral','bimestral','Manuel','2023-10-31 19:41:24','Manuel','2023-12-11 01:33:12','A'),(2,'Trimestral','Trimestral',NULL,'2023-10-31 21:03:54',NULL,'2023-12-11 01:33:07','A'),(3,'Cuatrimestral','Cuatrimestral','manu','2023-12-11 01:31:47','manu','2023-12-11 01:31:47','A'),(4,'Semestre','Semestre','manu','2023-12-11 01:32:23','manu','2023-12-11 01:32:23','A'),(5,'Semanal','Semanal','manu','2023-12-11 01:33:15','manu','2023-12-11 01:33:15','A'),(6,'Quincenal','Quincenal','manu','2023-12-11 01:34:18','manu','2023-12-11 01:34:18','A'),(7,'Mensual','Mensual','manu','2023-12-11 01:35:19','manu','2023-12-11 01:35:19','A');
/*!40000 ALTER TABLE `tbl_periodicidad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_practicas_por_produccion`
--

DROP TABLE IF EXISTS `tbl_practicas_por_produccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_practicas_por_produccion` (
  `Id_Practica_Produccion` bigint(20) NOT NULL AUTO_INCREMENT,
  `Id_Ficha` bigint(20) DEFAULT NULL,
  `Id_Productor` bigint(20) DEFAULT NULL,
  `Id_Tipo_Practica` bigint(20) DEFAULT NULL,
  `Descripcion` text DEFAULT NULL,
  `Id_Usuario` bigint(20) DEFAULT NULL,
  `Creado_Por` varchar(255) DEFAULT NULL,
  `Fecha_Creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `Modificado_Por` varchar(255) DEFAULT NULL,
  `Fecha_Modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('A','I') DEFAULT 'A',
  PRIMARY KEY (`Id_Practica_Produccion`),
  KEY `FK_Id_Ficha_Practica_Produccion` (`Id_Ficha`),
  KEY `FK_Id_Productor_Practica_Produccion` (`Id_Productor`),
  KEY `FK_Id_Tipo_Practica_Practica_Produccion` (`Id_Tipo_Practica`),
  CONSTRAINT `FK_Id_Ficha_Practica_Produccion` FOREIGN KEY (`Id_Ficha`) REFERENCES `fichas` (`id_ficha`),
  CONSTRAINT `FK_Id_Productor_Practica_Produccion` FOREIGN KEY (`Id_Productor`) REFERENCES `tbl_productor` (`id_productor`),
  CONSTRAINT `FK_Id_Tipo_Practica_Practica_Produccion` FOREIGN KEY (`Id_Tipo_Practica`) REFERENCES `tbl_tipo_practicas_productivas` (`id_tipo_practica`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_practicas_por_produccion`
--

LOCK TABLES `tbl_practicas_por_produccion` WRITE;
/*!40000 ALTER TABLE `tbl_practicas_por_produccion` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_practicas_por_produccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_produccion_agricola_anterior`
--

DROP TABLE IF EXISTS `tbl_produccion_agricola_anterior`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_produccion_agricola_anterior` (
  `Id_Produccion_Anterior` bigint(20) NOT NULL AUTO_INCREMENT,
  `Id_Ficha` bigint(20) DEFAULT NULL,
  `Id_Ubicacion` bigint(20) DEFAULT NULL,
  `Id_Productor` bigint(20) DEFAULT NULL,
  `Id_Tipo_Cultivo` bigint(20) DEFAULT NULL,
  `Superficie_Primera_Postrera` enum('Primera','Postrera') DEFAULT NULL,
  `Id_Medida_Primera_Postrera` bigint(20) DEFAULT NULL,
  `Produccion_Obtenida` decimal(10,2) DEFAULT NULL,
  `Id_Medida_Produccion_Obtenida` bigint(20) DEFAULT NULL,
  `Cantidad_Vendida` decimal(10,2) DEFAULT NULL,
  `Id_Medida_Vendida` bigint(20) DEFAULT NULL,
  `Precio_Venta` decimal(10,2) DEFAULT NULL,
  `A_Quien_Se_Vendio` varchar(255) DEFAULT NULL,
  `Descripcion` varchar(255) DEFAULT NULL,
  `Creado_Por` varchar(255) DEFAULT NULL,
  `Fecha_Creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `Modificado_Por` varchar(255) DEFAULT NULL,
  `Fecha_Modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Estado` enum('A','I') DEFAULT 'A',
  PRIMARY KEY (`Id_Produccion_Anterior`),
  KEY `FK_Id_Ficha_Produccion_Anterior` (`Id_Ficha`),
  KEY `FK_Id_Ubicacion_Produccion_Anterior` (`Id_Ubicacion`),
  KEY `FK_Id_Productor_Produccion_Anterior` (`Id_Productor`),
  KEY `FK_Id_Tipo_Cultivo_Produccion_Anterior` (`Id_Tipo_Cultivo`),
  KEY `FK_Id_Medida_Primera_Postrera` (`Id_Medida_Primera_Postrera`),
  KEY `FK_Id_Medida_Produccion_Obtenida` (`Id_Medida_Produccion_Obtenida`),
  KEY `FK_Id_Medida_Vendida` (`Id_Medida_Vendida`),
  CONSTRAINT `FK_Id_Ficha_Produccion_Anterior` FOREIGN KEY (`Id_Ficha`) REFERENCES `fichas` (`id_ficha`),
  CONSTRAINT `FK_Id_Medida_Primera_Postrera` FOREIGN KEY (`Id_Medida_Primera_Postrera`) REFERENCES `tbl_medidas_tierra` (`id_medida`),
  CONSTRAINT `FK_Id_Medida_Produccion_Obtenida` FOREIGN KEY (`Id_Medida_Produccion_Obtenida`) REFERENCES `tbl_medidas_tierra` (`id_medida`),
  CONSTRAINT `FK_Id_Medida_Vendida` FOREIGN KEY (`Id_Medida_Vendida`) REFERENCES `tbl_medidas_tierra` (`id_medida`),
  CONSTRAINT `FK_Id_Productor_Produccion_Anterior` FOREIGN KEY (`Id_Productor`) REFERENCES `tbl_productor` (`id_productor`),
  CONSTRAINT `FK_Id_Tipo_Cultivo_Produccion_Anterior` FOREIGN KEY (`Id_Tipo_Cultivo`) REFERENCES `tbl_tipo_cultivo` (`id_tipo_cultivo`),
  CONSTRAINT `FK_Id_Ubicacion_Produccion_Anterior` FOREIGN KEY (`Id_Ubicacion`) REFERENCES `tbl_ubicacion_productor` (`id_ubicacion`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_produccion_agricola_anterior`
--

LOCK TABLES `tbl_produccion_agricola_anterior` WRITE;
/*!40000 ALTER TABLE `tbl_produccion_agricola_anterior` DISABLE KEYS */;
INSERT INTO `tbl_produccion_agricola_anterior` VALUES (4,1,1,1,1,'',1,124.00,1,12.00,1,23.00,'ale sabillon','desc','Mfigue','2023-12-11 21:09:56',NULL,'2023-12-11 21:09:56','A'),(5,20,45,20,4,'Primera',3,1233.00,3,1000.00,3,100.00,'pulperia carlos',NULL,'Mfigue','2023-12-12 21:49:16',NULL,'2023-12-12 21:49:16','A');
/*!40000 ALTER TABLE `tbl_produccion_agricola_anterior` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_produccion_comercializacion`
--

DROP TABLE IF EXISTS `tbl_produccion_comercializacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_produccion_comercializacion` (
  `Id_Produccion_Comercio` bigint(20) NOT NULL AUTO_INCREMENT,
  `Id_Ficha` bigint(20) DEFAULT NULL,
  `Id_Ubicacion` bigint(20) DEFAULT NULL,
  `Id_Productor` bigint(20) DEFAULT NULL,
  `Id_Tipo_Produccion` bigint(20) DEFAULT NULL,
  `Cantidad_Produccion` decimal(10,2) DEFAULT NULL,
  `Id_Medida_Produccion` bigint(20) DEFAULT NULL,
  `Cantidad_Vendida` decimal(10,2) DEFAULT NULL,
  `Id_Medida_Venta` bigint(20) DEFAULT NULL,
  `Precio_Venta` decimal(10,2) DEFAULT NULL,
  `A_Quien_Se_Vendio` varchar(255) DEFAULT NULL,
  `Creado_Por` varchar(255) DEFAULT NULL,
  `Fecha_Creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `Modificado_Por` varchar(255) DEFAULT NULL,
  `Fecha_Modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('A','I') DEFAULT 'A',
  PRIMARY KEY (`Id_Produccion_Comercio`),
  KEY `FK_Id_Ficha_Produccion_Comercio` (`Id_Ficha`),
  KEY `FK_Id_Ubicacion_Produccion_Comercio` (`Id_Ubicacion`),
  KEY `FK_Id_Productor_Produccion_Comercio` (`Id_Productor`),
  KEY `FK_Id_Tipo_Produccion_Produccion_Comercio` (`Id_Tipo_Produccion`),
  KEY `FK_Id_Medida_Produccion_Produccion_Comercio` (`Id_Medida_Produccion`),
  KEY `FK_Id_Medida_Venta_Produccion_Comercio` (`Id_Medida_Venta`),
  CONSTRAINT `FK_Id_Ficha_Produccion_Comercio` FOREIGN KEY (`Id_Ficha`) REFERENCES `fichas` (`id_ficha`),
  CONSTRAINT `FK_Id_Medida_Produccion_Produccion_Comercio` FOREIGN KEY (`Id_Medida_Produccion`) REFERENCES `tbl_medidas_tierra` (`id_medida`),
  CONSTRAINT `FK_Id_Medida_Venta_Produccion_Comercio` FOREIGN KEY (`Id_Medida_Venta`) REFERENCES `tbl_medidas_tierra` (`id_medida`),
  CONSTRAINT `FK_Id_Productor_Produccion_Comercio` FOREIGN KEY (`Id_Productor`) REFERENCES `tbl_productor` (`id_productor`),
  CONSTRAINT `FK_Id_Tipo_Produccion_Produccion_Comercio` FOREIGN KEY (`Id_Tipo_Produccion`) REFERENCES `tbl_tipo_produccion` (`id_tipo_produccion`),
  CONSTRAINT `FK_Id_Ubicacion_Produccion_Comercio` FOREIGN KEY (`Id_Ubicacion`) REFERENCES `tbl_ubicacion_productor` (`id_ubicacion`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_produccion_comercializacion`
--

LOCK TABLES `tbl_produccion_comercializacion` WRITE;
/*!40000 ALTER TABLE `tbl_produccion_comercializacion` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_produccion_comercializacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_produccion_pecuaria`
--

DROP TABLE IF EXISTS `tbl_produccion_pecuaria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_produccion_pecuaria` (
  `Id_Produccion_Pecuaria` bigint(20) NOT NULL AUTO_INCREMENT,
  `Id_Ficha` bigint(20) DEFAULT NULL,
  `Id_Ubicacion` bigint(20) DEFAULT NULL,
  `Id_Productor` bigint(20) DEFAULT NULL,
  `Año_Produccion` int(11) DEFAULT NULL,
  `Id_Tipo_Pecuario` bigint(20) DEFAULT NULL,
  `Cantidad_Hembras` int(11) DEFAULT NULL,
  `Cantidad_Machos` int(11) DEFAULT NULL,
  `Cantidad_Total` int(11) DEFAULT NULL,
  `Descripcion_Otros` varchar(255) DEFAULT NULL,
  `Precio_Venta` decimal(10,2) DEFAULT NULL,
  `Id_Medida_Venta` bigint(20) DEFAULT NULL,
  `Cantidad_Mercado` int(11) DEFAULT NULL,
  `Descripcion` varchar(255) DEFAULT NULL,
  `Creado_Por` varchar(255) DEFAULT NULL,
  `Fecha_Creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `Modificado_Por` varchar(255) DEFAULT NULL,
  `Fecha_Modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Estado` enum('A','I') DEFAULT 'A',
  PRIMARY KEY (`Id_Produccion_Pecuaria`),
  KEY `FK_Id_Ubicacion_Produccion_Pecuaria` (`Id_Ubicacion`),
  KEY `FK_Id_Productor_Produccion_Pecuaria` (`Id_Productor`),
  KEY `FK_Id_Tipo_Pecuario_Produccion_Pecuaria` (`Id_Tipo_Pecuario`),
  KEY `FK_Id_Medida_Venta_Produccion_Pecuaria` (`Id_Medida_Venta`),
  KEY `FK_Id_Ficha_Produccion_Pecuaria` (`Id_Ficha`),
  CONSTRAINT `FK_Id_Ficha_Produccion_Pecuaria` FOREIGN KEY (`Id_Ficha`) REFERENCES `fichas` (`id_ficha`),
  CONSTRAINT `FK_Id_Medida_Venta_Produccion_Pecuaria` FOREIGN KEY (`Id_Medida_Venta`) REFERENCES `tbl_medidas_tierra` (`id_medida`),
  CONSTRAINT `FK_Id_Productor_Produccion_Pecuaria` FOREIGN KEY (`Id_Productor`) REFERENCES `tbl_productor` (`id_productor`),
  CONSTRAINT `FK_Id_Tipo_Pecuario_Produccion_Pecuaria` FOREIGN KEY (`Id_Tipo_Pecuario`) REFERENCES `tbl_tipo_pecuarios` (`id_tipo_pecuario`),
  CONSTRAINT `FK_Id_Ubicacion_Produccion_Pecuaria` FOREIGN KEY (`Id_Ubicacion`) REFERENCES `tbl_ubicacion_productor` (`id_ubicacion`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_produccion_pecuaria`
--

LOCK TABLES `tbl_produccion_pecuaria` WRITE;
/*!40000 ALTER TABLE `tbl_produccion_pecuaria` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_produccion_pecuaria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_produccion_vendida`
--

DROP TABLE IF EXISTS `tbl_produccion_vendida`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_produccion_vendida` (
  `Id_Produccion_Vendida` bigint(20) NOT NULL AUTO_INCREMENT,
  `Año_Venta` int(11) DEFAULT NULL,
  `Id_Tipo_Pecuario` bigint(20) DEFAULT NULL,
  `Precio_Venta` decimal(10,2) DEFAULT NULL,
  `Id_Medida_Venta` bigint(20) DEFAULT NULL,
  `Cantidad_Mercado` int(11) DEFAULT NULL,
  `Creado_Por` varchar(255) DEFAULT NULL,
  `Fecha_Creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `Modificado_Por` varchar(255) DEFAULT NULL,
  `Fecha_Modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Estado` enum('A','I') DEFAULT 'A',
  PRIMARY KEY (`Id_Produccion_Vendida`),
  KEY `FK_Id_Tipo_Pecuario_Produccion_Vendida` (`Id_Tipo_Pecuario`),
  KEY `FK_Id_Medida_Venta_Produccion_Vendida` (`Id_Medida_Venta`),
  CONSTRAINT `FK_Id_Medida_Venta_Produccion_Vendida` FOREIGN KEY (`Id_Medida_Venta`) REFERENCES `tbl_medidas_tierra` (`id_medida`),
  CONSTRAINT `FK_Id_Tipo_Pecuario_Produccion_Vendida` FOREIGN KEY (`Id_Tipo_Pecuario`) REFERENCES `tbl_tipo_pecuarios` (`id_tipo_pecuario`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_produccion_vendida`
--

LOCK TABLES `tbl_produccion_vendida` WRITE;
/*!40000 ALTER TABLE `tbl_produccion_vendida` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_produccion_vendida` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_productor`
--

DROP TABLE IF EXISTS `tbl_productor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_productor` (
  `id_ficha` bigint(20) DEFAULT NULL,
  `id_productor` bigint(20) NOT NULL AUTO_INCREMENT,
  `primer_nombre` varchar(255) DEFAULT NULL,
  `segundo_nombre` varchar(255) DEFAULT NULL,
  `primer_apellido` varchar(255) DEFAULT NULL,
  `segundo_apellido` varchar(255) DEFAULT NULL,
  `identificacion` bigint(20) DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `genero` varchar(10) DEFAULT NULL,
  `estado_civil` varchar(20) DEFAULT NULL,
  `nivel_escolaridad` varchar(50) DEFAULT NULL,
  `ultimo_grado_escolar_aprobado` varchar(50) DEFAULT NULL,
  `telefono_1` int(11) DEFAULT NULL,
  `telefono_2` int(11) DEFAULT NULL,
  `telefono_3` int(11) DEFAULT NULL,
  `email_1` varchar(255) DEFAULT NULL,
  `email_2` varchar(255) DEFAULT NULL,
  `email_3` varchar(255) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_por` varchar(25) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modificado_por` varchar(25) DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `estado` enum('A','I') DEFAULT NULL,
  PRIMARY KEY (`id_productor`),
  KEY `id_ficha` (`id_ficha`),
  CONSTRAINT `tbl_productor_ibfk_1` FOREIGN KEY (`id_ficha`) REFERENCES `fichas` (`id_ficha`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_productor`
--

LOCK TABLES `tbl_productor` WRITE;
/*!40000 ALTER TABLE `tbl_productor` DISABLE KEYS */;
INSERT INTO `tbl_productor` VALUES (1,1,'Manuel','Jesus','Figueroa','Barahona',801200205125,'2001-08-28','M','Soltero','Universitario','Bachillerato',31373917,NULL,NULL,'manuel_figueroa@gmail.com',NULL,NULL,'Creado por Manuel','1','2023-11-13 03:26:44','1','2023-11-13 03:26:44','A'),(2,2,'Kevin','ale','vaca','vaca',801200205125,'2023-11-17','M','Soltero','Universitario','Bachillerato',31373917,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-11-17 20:59:25',NULL,'2023-11-17 20:59:25','A'),(3,3,'manuel','jesus','figueroaas','barahona',801200205125,'2023-11-20','Masculino','Casado(a)','universitario','universitario',31673917,31673917,31673917,'manuelfigueroa2818@gmail.com','manuelfigueroa2818@gmail.com','manu@unah.hn','prueba','0','2023-11-20 06:54:47','0','2023-11-20 06:54:47','I'),(20,20,'manuel','jesus','figueroa','barahona',801200205125,'2023-12-12','Masculino','Soltero(a)','primaria','5',31673917,14253652,36251445,'manuelfigueroa2818@gmail.com','manuelfigueroa2818@gmail.com','manuelfigueroa2818@gmail.com',NULL,'Mfigue','2023-12-12 21:46:37',NULL,'2023-12-12 21:46:37','A'),(21,21,'','','','',0,'0000-00-00','','','','',0,0,0,'','','',NULL,'Mfigue','2023-12-12 22:14:12',NULL,'2023-12-12 22:14:12','A'),(23,23,'','','','',0,'0000-00-00','','','','',0,0,0,'','','',NULL,'Mfigue','2023-12-13 00:05:05',NULL,'2023-12-13 00:05:05','A');
/*!40000 ALTER TABLE `tbl_productor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_productor_actividad_externa`
--

DROP TABLE IF EXISTS `tbl_productor_actividad_externa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_productor_actividad_externa` (
  `id_actividad_ext` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_ficha` bigint(20) DEFAULT NULL,
  `id_productor` bigint(20) DEFAULT NULL,
  `miembros_realizan_actividades_fuera_finca` enum('S','N') DEFAULT NULL,
  `id_tomador_decisiones` bigint(20) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_por` varchar(255) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modificado_por` varchar(255) DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('A','I') DEFAULT 'A',
  PRIMARY KEY (`id_actividad_ext`),
  KEY `fk_id_ficha_actividad_externa` (`id_ficha`),
  KEY `fk_id_productor_actividad_externa` (`id_productor`),
  KEY `fk_id_tomador_decisiones_actividad_externa` (`id_tomador_decisiones`),
  CONSTRAINT `fk_id_ficha_actividad_externa` FOREIGN KEY (`id_ficha`) REFERENCES `fichas` (`id_ficha`),
  CONSTRAINT `fk_id_productor_actividad_externa` FOREIGN KEY (`id_productor`) REFERENCES `tbl_productor` (`id_productor`),
  CONSTRAINT `fk_id_tomador_decisiones_actividad_externa` FOREIGN KEY (`id_tomador_decisiones`) REFERENCES `tbl_toma_decisiones` (`id_tipo_tomador`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_productor_actividad_externa`
--

LOCK TABLES `tbl_productor_actividad_externa` WRITE;
/*!40000 ALTER TABLE `tbl_productor_actividad_externa` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_productor_actividad_externa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_relevo_organizacion`
--

DROP TABLE IF EXISTS `tbl_relevo_organizacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_relevo_organizacion` (
  `id_ficha` bigint(20) DEFAULT NULL,
  `id_productor` bigint(20) DEFAULT NULL,
  `Id_Relevo` bigint(20) NOT NULL AUTO_INCREMENT,
  `tendra_relevo` enum('S','N') DEFAULT NULL,
  `cuantos_relevos` int(11) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_por` varchar(50) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `modificado_por` varchar(50) DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('A','I') DEFAULT 'A',
  PRIMARY KEY (`Id_Relevo`),
  KEY `fk_id_ficha` (`id_ficha`),
  KEY `fk_id_productor_relevo` (`id_productor`),
  CONSTRAINT `fk_id_ficha` FOREIGN KEY (`id_ficha`) REFERENCES `fichas` (`id_ficha`),
  CONSTRAINT `fk_id_productor_relevo` FOREIGN KEY (`id_productor`) REFERENCES `tbl_productor` (`id_productor`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_relevo_organizacion`
--

LOCK TABLES `tbl_relevo_organizacion` WRITE;
/*!40000 ALTER TABLE `tbl_relevo_organizacion` DISABLE KEYS */;
INSERT INTO `tbl_relevo_organizacion` VALUES (20,20,20,'S',23,NULL,'Mfigue','2023-12-12 21:48:04',NULL,'2023-12-12 21:48:04','A'),(21,21,21,'N',0,NULL,'Mfigue','2023-12-12 22:14:16',NULL,'2023-12-12 22:14:16','A'),(23,23,23,'N',0,NULL,'Mfigue','2023-12-13 00:05:28',NULL,'2023-12-13 00:05:28','A');
/*!40000 ALTER TABLE `tbl_relevo_organizacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_tipo_cultivo`
--

DROP TABLE IF EXISTS `tbl_tipo_cultivo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tipo_cultivo` (
  `id_tipo_cultivo` bigint(20) NOT NULL AUTO_INCREMENT,
  `tipo_cultivo` varchar(255) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_por` varchar(255) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `modificado_por` varchar(255) DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('ACTIVO','INACTIVO','','') DEFAULT NULL,
  PRIMARY KEY (`id_tipo_cultivo`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_tipo_cultivo`
--

LOCK TABLES `tbl_tipo_cultivo` WRITE;
/*!40000 ALTER TABLE `tbl_tipo_cultivo` DISABLE KEYS */;
INSERT INTO `tbl_tipo_cultivo` VALUES (1,'Maiz','Maiz amarillo','Manuel','2023-12-01 04:18:29',NULL,'2023-11-02 04:18:29','ACTIVO'),(4,'Frijol','ADS','Manuel','2023-11-02 05:10:49','Manuel','2023-11-02 05:10:49','ACTIVO');
/*!40000 ALTER TABLE `tbl_tipo_cultivo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_tipo_negocios`
--

DROP TABLE IF EXISTS `tbl_tipo_negocios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tipo_negocios` (
  `id_tipo_negocio` bigint(20) NOT NULL AUTO_INCREMENT,
  `tipo_negocio` varchar(255) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_por` varchar(255) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modificado_por` varchar(255) DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('A','I') DEFAULT NULL,
  PRIMARY KEY (`id_tipo_negocio`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_tipo_negocios`
--

LOCK TABLES `tbl_tipo_negocios` WRITE;
/*!40000 ALTER TABLE `tbl_tipo_negocios` DISABLE KEYS */;
INSERT INTO `tbl_tipo_negocios` VALUES (1,'Venta de servicio','Venta de servicios','Kevin','2023-12-11 09:36:51','Kevin','2023-12-11 09:36:51',''),(4,'Jornal agricola','Jornal agricola','Kevin','2023-12-11 09:37:31','Kevin','2023-12-11 09:37:31',''),(5,'Corte de café','Café',NULL,'2023-12-11 10:08:49',NULL,'2023-12-11 10:08:49',''),(6,'Jornal no agrícola',NULL,NULL,'2023-12-11 09:46:37',NULL,'2023-12-11 09:46:37',NULL),(7,'Alquileres',NULL,NULL,'2023-12-11 09:46:37',NULL,'2023-12-11 09:46:37',NULL),(8,'Remesa del exterior',NULL,NULL,'2023-12-11 09:46:37',NULL,'2023-12-11 09:46:37',NULL),(9,'Remesa nacional',NULL,NULL,'2023-12-11 09:46:37',NULL,'2023-12-11 09:46:37',NULL),(10,'Bono',NULL,NULL,'2023-12-11 09:46:37',NULL,'2023-12-11 09:46:37',NULL),(11,'Salario profesional',NULL,NULL,'2023-12-11 09:46:37',NULL,'2023-12-11 09:46:37',NULL),(12,'Artesanía',NULL,NULL,'2023-12-11 09:46:37',NULL,'2023-12-11 09:46:37',NULL);
/*!40000 ALTER TABLE `tbl_tipo_negocios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_tipo_organizacion`
--

DROP TABLE IF EXISTS `tbl_tipo_organizacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tipo_organizacion` (
  `id_tipo_organizacion` bigint(20) NOT NULL AUTO_INCREMENT,
  `tipo_organizacion` varchar(255) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_por` varchar(255) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modificado_por` varchar(255) DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('A','I') DEFAULT NULL,
  PRIMARY KEY (`id_tipo_organizacion`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_tipo_organizacion`
--

LOCK TABLES `tbl_tipo_organizacion` WRITE;
/*!40000 ALTER TABLE `tbl_tipo_organizacion` DISABLE KEYS */;
INSERT INTO `tbl_tipo_organizacion` VALUES (1,'BENEFICA','Grupo Solidario ','1','2023-11-16 06:22:08','1','2023-11-16 06:22:08','A'),(2,'Cooperativa','cooperativas','manu','2023-11-16 06:22:15','manu','2023-11-16 06:22:15','A');
/*!40000 ALTER TABLE `tbl_tipo_organizacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_tipo_pecuarios`
--

DROP TABLE IF EXISTS `tbl_tipo_pecuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tipo_pecuarios` (
  `id_tipo_pecuario` bigint(20) NOT NULL AUTO_INCREMENT,
  `tipo_pecuario` varchar(25) NOT NULL,
  `raza_con_genero` enum('s','n') DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_por` varchar(50) DEFAULT NULL,
  `fecha_creacion` timestamp NULL DEFAULT current_timestamp(),
  `modificado_por` varchar(50) DEFAULT NULL,
  `fecha_modificacion` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('A','I') DEFAULT NULL,
  PRIMARY KEY (`id_tipo_pecuario`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_tipo_pecuarios`
--

LOCK TABLES `tbl_tipo_pecuarios` WRITE;
/*!40000 ALTER TABLE `tbl_tipo_pecuarios` DISABLE KEYS */;
INSERT INTO `tbl_tipo_pecuarios` VALUES (1,'Bovinos','s','asasa','manu','2023-11-26 06:00:00','manu','2023-12-11 01:15:58','A'),(2,'Ovinos','s','prueba','manu','2023-11-26 06:13:32','manu','2023-12-11 01:15:45','A'),(3,'Caprinos','s','Caprinos','manu','2023-11-26 06:29:31','manu','2023-12-11 01:15:30','A'),(4,'Cerdo','s','Cerdos','Mfigue','2023-12-11 01:11:16',NULL,'2023-12-11 01:11:49','A'),(5,'Pollo de Engorde','s','Pollo de Engorde','manu','2023-12-11 01:11:57','manu','2023-12-11 01:11:57','A'),(6,'Aves','n','Aves','manu','2023-12-11 01:12:58','manu','2023-12-11 01:12:58','A'),(7,'Peces','n','Peces','manu','2023-12-11 01:13:38','manu','2023-12-11 01:13:38',NULL),(8,'Camarones','n','Camarones','manu','2023-12-11 01:14:08','manu','2023-12-11 01:14:08','A'),(9,'Otros','n','Otras especies','manu','2023-12-11 01:14:44','manu','2023-12-11 01:14:44',NULL);
/*!40000 ALTER TABLE `tbl_tipo_pecuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_tipo_practicas_productivas`
--

DROP TABLE IF EXISTS `tbl_tipo_practicas_productivas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tipo_practicas_productivas` (
  `id_tipo_practica` bigint(20) NOT NULL AUTO_INCREMENT,
  `tipo_practica` varchar(255) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_por` varchar(255) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modificado_por` varchar(255) DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('A','I') DEFAULT NULL,
  PRIMARY KEY (`id_tipo_practica`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_tipo_practicas_productivas`
--

LOCK TABLES `tbl_tipo_practicas_productivas` WRITE;
/*!40000 ALTER TABLE `tbl_tipo_practicas_productivas` DISABLE KEYS */;
INSERT INTO `tbl_tipo_practicas_productivas` VALUES (1,'Quema',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(2,'Riega',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(3,'Manejo de rastrojo',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(4,'Cero labranzas',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(5,'Labranza mínima',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(6,'Siembra en hileras o surcos',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(7,'Curvas a nivel',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(8,'Cultivos en asoci',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(9,'Desparasitantes',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(10,'Preparación de suelo con tractor',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(11,'Cultivo en relevo',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(12,'Tierra en descanso',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(13,'Barreras vivas',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(14,'Barreras muertas',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(15,'Abono orgánico',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(16,'Abono sintético',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(17,'Cosecha de agua',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(18,'Manejo de humedad',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(19,'Semilla criolla',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(20,'Semilla mejorada',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(21,'Huerto familiar',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(22,'Almacenamiento de grano',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(23,'Agricultura protegida',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(24,'Secadora solar',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(25,'Uso de insecticidas',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(26,'Uso de fungicidas',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(27,'Uso de acaricidas',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(28,'Uso de herbicidas',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(29,'Podas',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(30,'Sistema agroforestal',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(31,'Control de sombra',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(32,'Sistema silvopastoril',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(33,'Terrazas',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(34,'Cultivo de cobertura',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(35,'Banco de proteína',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(36,'Pastos mejorados',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(37,'Aplicación de vacunas',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(38,'Vitaminas',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A'),(39,'Preparación de suelo con tracción animal',NULL,NULL,'2023-12-12 17:05:48',NULL,'2023-12-12 17:05:48','A');
/*!40000 ALTER TABLE `tbl_tipo_practicas_productivas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_tipo_produccion`
--

DROP TABLE IF EXISTS `tbl_tipo_produccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tipo_produccion` (
  `id_tipo_produccion` bigint(20) NOT NULL AUTO_INCREMENT,
  `tipo_produccion` varchar(255) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_por` varchar(255) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modificado_por` varchar(255) DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('ACTIVO','INACTIVO','','') DEFAULT NULL,
  PRIMARY KEY (`id_tipo_produccion`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_tipo_produccion`
--

LOCK TABLES `tbl_tipo_produccion` WRITE;
/*!40000 ALTER TABLE `tbl_tipo_produccion` DISABLE KEYS */;
INSERT INTO `tbl_tipo_produccion` VALUES (1,'Maiz','Maiz Blanco','1','2023-11-04 06:06:10','1','2023-11-04 06:06:10','ACTIVO'),(2,'Cafe','Cafe de palo','Kevin','2023-12-11 01:48:11','Kevin','2023-12-11 01:48:11','ACTIVO'),(3,'Frijol','Frijol','Kevin','2023-12-11 01:43:56','Kevin','2023-12-11 01:43:56','ACTIVO'),(4,'Palma','Palma','Kevin','2023-12-11 01:44:24','Kevin','2023-12-11 01:44:24','ACTIVO'),(5,'Caña de Azúcar','Caña de Azúcar','manu','2023-12-11 01:44:45','manu','2023-12-11 01:44:45','ACTIVO'),(6,'Sorgo','Sorgo','manu','2023-12-11 01:45:19','manu','2023-12-11 01:45:19','ACTIVO'),(7,'Naranja','Naranja','manu','2023-12-11 01:45:19','manu','2023-12-11 01:45:19','ACTIVO'),(8,'Banano','Banano','manu','2023-12-11 01:46:35','manu','2023-12-11 01:46:35','ACTIVO'),(9,'Melón','Melón','manu','2023-12-11 01:47:49','manu','2023-12-11 01:47:49','ACTIVO');
/*!40000 ALTER TABLE `tbl_tipo_produccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_tipo_riego`
--

DROP TABLE IF EXISTS `tbl_tipo_riego`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tipo_riego` (
  `id_tipo_riego` bigint(20) NOT NULL AUTO_INCREMENT,
  `tipo_riego` varchar(255) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_por` varchar(255) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `modificado_por` varchar(255) DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('ACTIVO','INACTIVO','','') DEFAULT NULL,
  PRIMARY KEY (`id_tipo_riego`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_tipo_riego`
--

LOCK TABLES `tbl_tipo_riego` WRITE;
/*!40000 ALTER TABLE `tbl_tipo_riego` DISABLE KEYS */;
INSERT INTO `tbl_tipo_riego` VALUES (1,'Pozo','Pozo','Manuel','2023-11-02 05:23:18','Manuel','2023-11-02 05:23:18','ACTIVO');
/*!40000 ALTER TABLE `tbl_tipo_riego` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_tipo_trabajadores`
--

DROP TABLE IF EXISTS `tbl_tipo_trabajadores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tipo_trabajadores` (
  `id_tipo_trabajador` bigint(20) NOT NULL AUTO_INCREMENT,
  `tipo_trabajador` varchar(255) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_por` varchar(255) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modificado_por` varchar(255) DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('A','I') DEFAULT NULL,
  PRIMARY KEY (`id_tipo_trabajador`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_tipo_trabajadores`
--

LOCK TABLES `tbl_tipo_trabajadores` WRITE;
/*!40000 ALTER TABLE `tbl_tipo_trabajadores` DISABLE KEYS */;
INSERT INTO `tbl_tipo_trabajadores` VALUES (1,'Ganadero','kkka','Daniela','2023-11-22 06:17:22','Daniela','2023-11-22 06:17:22','I'),(2,'Agricultor','3 cultivos de papa','Daniela','2023-11-22 06:17:27','Daniela','2023-11-22 06:17:27','A');
/*!40000 ALTER TABLE `tbl_tipo_trabajadores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_tipos_apoyo_produccion`
--

DROP TABLE IF EXISTS `tbl_tipos_apoyo_produccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tipos_apoyo_produccion` (
  `id_apoyo_produccion` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_ficha` bigint(20) DEFAULT NULL,
  `id_productor` bigint(20) DEFAULT NULL,
  `id_tipos_apoyos` bigint(20) NOT NULL,
  `otros_detalles` text DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_por` varchar(255) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modificado_por` varchar(255) DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('A','I') DEFAULT NULL,
  PRIMARY KEY (`id_apoyo_produccion`) USING BTREE,
  KEY `fk_id_ficha_apoyo_produccion` (`id_ficha`),
  KEY `fk_id_productor_apoyo_produccion` (`id_productor`),
  KEY `fk_id_tipos_apoyos_apoyo_produccion` (`id_tipos_apoyos`),
  CONSTRAINT `fk_id_ficha_apoyo_produccion` FOREIGN KEY (`id_ficha`) REFERENCES `fichas` (`id_ficha`),
  CONSTRAINT `fk_id_productor_apoyo_produccion` FOREIGN KEY (`id_productor`) REFERENCES `tbl_productor` (`id_productor`),
  CONSTRAINT `fk_id_tipos_apoyos_apoyo_produccion` FOREIGN KEY (`id_tipos_apoyos`) REFERENCES `tbl_tipos_apoyos` (`id_tipo_apoyos`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_tipos_apoyo_produccion`
--

LOCK TABLES `tbl_tipos_apoyo_produccion` WRITE;
/*!40000 ALTER TABLE `tbl_tipos_apoyo_produccion` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_tipos_apoyo_produccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_tipos_apoyos`
--

DROP TABLE IF EXISTS `tbl_tipos_apoyos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tipos_apoyos` (
  `id_tipo_apoyos` bigint(11) NOT NULL AUTO_INCREMENT,
  `tipo_apoyos` varchar(255) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_por` varchar(255) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modificado_por` varchar(255) DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('ACTIVO','INACTIVO') DEFAULT NULL,
  PRIMARY KEY (`id_tipo_apoyos`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_tipos_apoyos`
--

LOCK TABLES `tbl_tipos_apoyos` WRITE;
/*!40000 ALTER TABLE `tbl_tipos_apoyos` DISABLE KEYS */;
INSERT INTO `tbl_tipos_apoyos` VALUES (1,'Crédito','Descripción del apoyo de Crédito','admin','2023-12-12 20:53:05',NULL,'2023-12-12 20:53:05','ACTIVO'),(2,'Semilla','Descripción del apoyo de Semilla','admin','2023-12-12 20:53:05',NULL,'2023-12-12 20:53:05','ACTIVO'),(3,'Fertilizante','Descripción del apoyo de Fertilizante','admin','2023-12-12 20:53:05',NULL,'2023-12-12 20:53:05','ACTIVO'),(4,'Capacitación','Descripción del apoyo de Capacitación','admin','2023-12-12 20:53:05',NULL,'2023-12-12 20:53:05','ACTIVO'),(5,'Asistencia técnica','Descripción del apoyo de Asistencia técnica','admin','2023-12-12 20:53:05',NULL,'2023-12-12 20:53:05','ACTIVO'),(6,'Herramientas de trabajo','Descripción del apoyo de Herramientas de trabajo','admin','2023-12-12 20:53:05',NULL,'2023-12-12 20:53:05','ACTIVO'),(7,'Sistema de riego','Descripción del apoyo de Sistema de riego','admin','2023-12-12 20:53:05',NULL,'2023-12-12 20:53:05','ACTIVO'),(8,'Equipo agrícola','Descripción del apoyo de Equipo agrícola','admin','2023-12-12 20:53:05',NULL,'2023-12-12 20:53:05','ACTIVO'),(9,'Silos','Descripción del apoyo de Silos','admin','2023-12-12 20:53:05',NULL,'2023-12-12 20:53:05','ACTIVO'),(10,'Cosechadoras de agua','Descripción del apoyo de Cosechadoras de agua','admin','2023-12-12 20:53:05',NULL,'2023-12-12 20:53:05','ACTIVO'),(11,'Pie de cría','Descripción del apoyo de Pie de cría','admin','2023-12-12 20:53:05',NULL,'2023-12-12 20:53:05','ACTIVO'),(12,'Información de precios','Descripción del apoyo de Información de precios','admin','2023-12-12 20:53:05',NULL,'2023-12-12 20:53:05','ACTIVO'),(13,'Comercialización/mercados','Descripción del apoyo de Comercialización/mercados','admin','2023-12-12 20:53:05',NULL,'2023-12-12 20:53:05','ACTIVO'),(14,'Organización rural','Descripción del apoyo de Organización rural','admin','2023-12-12 20:53:05',NULL,'2023-12-12 20:53:05','ACTIVO'),(15,'Transformación de productos','Descripción del apoyo de Transformación de productos','admin','2023-12-12 20:53:05',NULL,'2023-12-12 20:53:05','ACTIVO');
/*!40000 ALTER TABLE `tbl_tipos_apoyos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_toma_decisiones`
--

DROP TABLE IF EXISTS `tbl_toma_decisiones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_toma_decisiones` (
  `id_tipo_tomador` bigint(20) NOT NULL AUTO_INCREMENT,
  `tomador` varchar(255) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_por` varchar(255) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modificado_por` varchar(255) DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('A','I') DEFAULT NULL,
  PRIMARY KEY (`id_tipo_tomador`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_toma_decisiones`
--

LOCK TABLES `tbl_toma_decisiones` WRITE;
/*!40000 ALTER TABLE `tbl_toma_decisiones` DISABLE KEYS */;
INSERT INTO `tbl_toma_decisiones` VALUES (1,'SAG','Se decidio por voto','Daniela','2023-11-22 06:16:04','Daniela','2023-11-22 06:16:04','A'),(2,'SAG 1','Creacion de base 1','Daniela','2023-11-22 06:15:53','Daniela','2023-11-22 06:15:53','A'),(3,'UPEG1','Pagos1','Daniela','2023-11-22 06:15:58','Daniela','2023-11-22 06:15:58','I');
/*!40000 ALTER TABLE `tbl_toma_decisiones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_trabajadores_externos`
--

DROP TABLE IF EXISTS `tbl_trabajadores_externos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_trabajadores_externos` (
  `id_trabajador_ext` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_ficha` bigint(20) DEFAULT NULL,
  `id_productor` bigint(20) DEFAULT NULL,
  `id_tipo_trabajador` bigint(20) DEFAULT NULL,
  `cantidad_trabajador` int(11) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_por` varchar(255) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modificado_por` varchar(255) DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('A','I') DEFAULT NULL,
  PRIMARY KEY (`id_trabajador_ext`),
  KEY `fk_id_ficha_trabajadores_externos` (`id_ficha`),
  KEY `fk_id_productor_trabajadores_externos` (`id_productor`),
  KEY `fk_id_tipo_trabajador` (`id_tipo_trabajador`),
  CONSTRAINT `fk_id_ficha_trabajadores_externos` FOREIGN KEY (`id_ficha`) REFERENCES `fichas` (`id_ficha`),
  CONSTRAINT `fk_id_productor_trabajadores_externos` FOREIGN KEY (`id_productor`) REFERENCES `tbl_productor` (`id_productor`),
  CONSTRAINT `fk_id_tipo_trabajador` FOREIGN KEY (`id_tipo_trabajador`) REFERENCES `tbl_tipo_trabajadores` (`id_tipo_trabajador`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_trabajadores_externos`
--

LOCK TABLES `tbl_trabajadores_externos` WRITE;
/*!40000 ALTER TABLE `tbl_trabajadores_externos` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_trabajadores_externos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_ubicacion_productor`
--

DROP TABLE IF EXISTS `tbl_ubicacion_productor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_ubicacion_productor` (
  `id_ficha` bigint(20) DEFAULT NULL,
  `id_productor` bigint(20) DEFAULT NULL,
  `id_ubicacion` bigint(20) NOT NULL AUTO_INCREMENT,
  `Id_Departamento` bigint(20) NOT NULL,
  `Id_Municipio` bigint(20) NOT NULL,
  `Id_Aldea` bigint(20) NOT NULL,
  `Id_Cacerio` bigint(20) NOT NULL,
  `ubicacion_geografica` varchar(255) DEFAULT NULL,
  `distancia_parcela_vivienda` decimal(10,2) DEFAULT NULL,
  `latitud_parcela` varchar(20) DEFAULT NULL,
  `longitud_parcela` varchar(20) DEFAULT NULL,
  `msnm` decimal(10,2) DEFAULT NULL,
  `direccion_1` varchar(255) DEFAULT NULL,
  `direccion_2` varchar(255) DEFAULT NULL,
  `direccion_3` varchar(255) DEFAULT NULL,
  `vive_en_finca` enum('S','N') DEFAULT NULL,
  `nombre_finca` varchar(255) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_por` varchar(50) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `modificado_por` varchar(50) DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('A','I') DEFAULT 'A',
  PRIMARY KEY (`id_ubicacion`),
  KEY `id_productor` (`id_productor`),
  KEY `fk_id_ficha_ubicacion` (`id_ficha`),
  KEY `fk_departamento_ubicacion_productor` (`Id_Departamento`),
  KEY `fk_municipio_ubicacion_productor` (`Id_Municipio`),
  KEY `fk_aldea_ubicacion_productor` (`Id_Aldea`),
  KEY `fk_cacerio_ubicacion_productor` (`Id_Cacerio`),
  CONSTRAINT `fk_aldea_ubicacion_productor` FOREIGN KEY (`Id_Aldea`) REFERENCES `tbl_aldeas` (`Id_Aldea`),
  CONSTRAINT `fk_cacerio_ubicacion_productor` FOREIGN KEY (`Id_Cacerio`) REFERENCES `tbl_cacerios` (`Id_Cacerio`),
  CONSTRAINT `fk_departamento_ubicacion_productor` FOREIGN KEY (`Id_Departamento`) REFERENCES `tbl_departamentos` (`Id_Departamento`),
  CONSTRAINT `fk_id_ficha_ubicacion` FOREIGN KEY (`id_ficha`) REFERENCES `fichas` (`id_ficha`),
  CONSTRAINT `fk_municipio_ubicacion_productor` FOREIGN KEY (`Id_Municipio`) REFERENCES `tbl_municipios` (`Id_Municipio`),
  CONSTRAINT `tbl_ubicacion_productor_ibfk_5` FOREIGN KEY (`id_productor`) REFERENCES `tbl_productor` (`id_productor`),
  CONSTRAINT `tbl_ubicacion_productor_ibfk_6` FOREIGN KEY (`id_productor`) REFERENCES `tbl_productor` (`id_productor`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_ubicacion_productor`
--

LOCK TABLES `tbl_ubicacion_productor` WRITE;
/*!40000 ALTER TABLE `tbl_ubicacion_productor` DISABLE KEYS */;
INSERT INTO `tbl_ubicacion_productor` VALUES (1,1,1,1,1,1,1,'col. quezada',12.00,'1','2',3.00,'col. quezada','col. quezada','col. quezada','S','col. quezada','col. quezada','manu','2023-12-10 14:50:00','manu','2023-12-10 14:50:00','A'),(20,20,45,1,1,1,1,'Comayagua',1.00,'2','3',4.00,'col arturo quezada','bloque 15 ','avenida 7 casa 3323','S','la quezada',NULL,'Mfigue','2023-12-12 21:47:27',NULL,'2023-12-12 21:47:27','A'),(21,21,46,1,1,1,1,'',0.00,'','',0.00,'','','','','',NULL,'Mfigue','2023-12-12 22:14:12',NULL,'2023-12-12 22:14:12','A'),(23,23,48,1,1,1,1,'',0.00,'','',0.00,'','','','','',NULL,'Mfigue','2023-12-13 00:05:06',NULL,'2023-12-13 00:05:06','A');
/*!40000 ALTER TABLE `tbl_ubicacion_productor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_unidad_productora`
--

DROP TABLE IF EXISTS `tbl_unidad_productora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_unidad_productora` (
  `Id_Ubicacion` bigint(20) NOT NULL,
  `Id_Ficha` bigint(20) DEFAULT NULL,
  `Id_Unidad_Productiva` bigint(20) NOT NULL AUTO_INCREMENT,
  `Id_Productor` bigint(20) DEFAULT NULL,
  `Tipo_De_Manejo` enum('Propia','Alquilada','Prestada','Ejidal') DEFAULT NULL,
  `Superficie_Produccion` decimal(10,2) DEFAULT NULL,
  `Id_Medida_Produccion` bigint(20) DEFAULT NULL,
  `Superficie_Agricultura` decimal(10,2) DEFAULT NULL,
  `Id_Medida_Agricultura` bigint(20) DEFAULT NULL,
  `Superficie_Ganaderia` decimal(10,2) DEFAULT NULL,
  `Id_Medida_Ganaderia` bigint(20) DEFAULT NULL,
  `Superficie_Apicultura` decimal(10,2) DEFAULT NULL,
  `Id_Medida_Apicultura` bigint(20) DEFAULT NULL,
  `Superficie_Forestal` decimal(10,2) DEFAULT NULL,
  `Id_Medida_Forestal` bigint(20) DEFAULT NULL,
  `Superficie_Acuacultura` decimal(10,2) DEFAULT NULL,
  `Numero_Estanques` int(11) DEFAULT NULL,
  `Superficie_Agroturismo` decimal(10,2) DEFAULT NULL,
  `Superficie_Otros` decimal(10,2) DEFAULT NULL,
  `Otros_Descripcion` varchar(255) DEFAULT NULL,
  `Descripcion` varchar(255) DEFAULT NULL,
  `Creado_Por` varchar(255) DEFAULT NULL,
  `Fecha_Creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `Modificado_Por` varchar(255) DEFAULT NULL,
  `Fecha_Modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('A','I') DEFAULT 'A',
  PRIMARY KEY (`Id_Unidad_Productiva`),
  KEY `FK_Id_Ficha_Unidad_Productora` (`Id_Ficha`),
  KEY `FK_Id_Ubicacion_Unidad_Productora` (`Id_Ubicacion`),
  KEY `FK_Id_Productor_Unidad_Productora` (`Id_Productor`),
  KEY `FK_Id_Medida_Produccion` (`Id_Medida_Produccion`),
  KEY `FK_Id_Medida_Agricultura` (`Id_Medida_Agricultura`),
  KEY `FK_Id_Medida_Ganaderia` (`Id_Medida_Ganaderia`),
  KEY `FK_Id_Medida_Apicultura` (`Id_Medida_Apicultura`),
  KEY `FK_Id_Medida_Forestal` (`Id_Medida_Forestal`),
  CONSTRAINT `FK_Id_Ficha_Unidad_Productora` FOREIGN KEY (`Id_Ficha`) REFERENCES `fichas` (`id_ficha`),
  CONSTRAINT `FK_Id_Medida_Agricultura` FOREIGN KEY (`Id_Medida_Agricultura`) REFERENCES `tbl_medidas_tierra` (`id_medida`),
  CONSTRAINT `FK_Id_Medida_Apicultura` FOREIGN KEY (`Id_Medida_Apicultura`) REFERENCES `tbl_medidas_tierra` (`id_medida`),
  CONSTRAINT `FK_Id_Medida_Forestal` FOREIGN KEY (`Id_Medida_Forestal`) REFERENCES `tbl_medidas_tierra` (`id_medida`),
  CONSTRAINT `FK_Id_Medida_Ganaderia` FOREIGN KEY (`Id_Medida_Ganaderia`) REFERENCES `tbl_medidas_tierra` (`id_medida`),
  CONSTRAINT `FK_Id_Medida_Produccion` FOREIGN KEY (`Id_Medida_Produccion`) REFERENCES `tbl_medidas_tierra` (`id_medida`),
  CONSTRAINT `FK_Id_Productor_Unidad_Productora` FOREIGN KEY (`Id_Productor`) REFERENCES `tbl_productor` (`id_productor`),
  CONSTRAINT `FK_Id_Ubicacion_Unidad_Productora` FOREIGN KEY (`Id_Ubicacion`) REFERENCES `tbl_ubicacion_productor` (`id_ubicacion`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_unidad_productora`
--

LOCK TABLES `tbl_unidad_productora` WRITE;
/*!40000 ALTER TABLE `tbl_unidad_productora` DISABLE KEYS */;
INSERT INTO `tbl_unidad_productora` VALUES (46,21,6,21,'Propia',100.00,2,100.00,2,100.00,2,100.00,2,10.00,3,10.00,3,15.00,100.00,NULL,NULL,'manu','2023-12-12 22:19:38',NULL,'2023-12-12 22:19:38','A');
/*!40000 ALTER TABLE `tbl_unidad_productora` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario` (
  `Id_Usuario` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_rol` bigint(20) NOT NULL,
  `nombre_completo` varchar(255) NOT NULL,
  `correo` varchar(255) NOT NULL,
  `usuario` varchar(255) NOT NULL,
  `contrasena` varchar(255) NOT NULL,
  `Token` varchar(100) DEFAULT NULL,
  `Fecha_Vencimiento_Token` datetime DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `Actualizado_Por` bigint(20) NOT NULL,
  `Fecha_Actualizacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `Preguntas_Contestadas` int(11) NOT NULL,
  `Estado` enum('ACTIVO','INACTIVO','PENDIENTE','BLOQUEADO') NOT NULL,
  `id_estado` bigint(20) NOT NULL,
  `Primera_Vez` enum('SI','NO') NOT NULL,
  `fecha_vencimiento` timestamp NOT NULL DEFAULT current_timestamp(),
  `Intentos_Preguntas` int(3) DEFAULT NULL,
  `Preguntas_Correctas` int(3) DEFAULT NULL,
  `Intentos_Fallidos` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id_Usuario`),
  KEY `Estado` (`id_estado`),
  KEY `Rol` (`id_rol`),
  CONSTRAINT `Estado` FOREIGN KEY (`Id_estado`) REFERENCES `estado_usuario` (`id_estado`),
  CONSTRAINT `Rol` FOREIGN KEY (`Id_rol`) REFERENCES `roles` (`Id_rol`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (1,1,'manuel','manuel@gmail.com','manu','123','1',NULL,'2023-10-29 01:48:15',1,'2023-10-30 01:48:15',1,'ACTIVO',1,'SI','2023-10-31 06:00:00',NULL,NULL,0),(9,2,'MANUEL FIGUEROA','manuelfigueroa2818@gmail.com','HARU','$2y$10$WHs2RM.ozD3KRQu1Dq8Ks.adgThvWCNojDPlhvYpVulktVmlC18/q',NULL,NULL,'2023-12-10 14:00:24',0,'2023-12-10 07:00:24',0,'ACTIVO',1,'SI','1970-01-01 07:00:00',NULL,NULL,0),(11,2,'MANUEL FIGUEROA BARAHONA','mdfigueroa@unah.hn','MANUBARA','$2y$10$UF/ahTJn5okUojk8aTN/uOiuWNJ2AnDdySKNNewLKLaC7WtZORzTu',NULL,NULL,'2023-12-10 22:25:54',0,'2023-12-10 15:25:54',0,'ACTIVO',1,'SI','2024-12-04 22:25:54',NULL,NULL,0),(12,2,'CARLOS VACA','manubara200128@gmail.com','Mfigue','$2y$10$BY5MYs7ff2W6r1vcQbr.EO6H.uzBsekloyLwFHOg8TuvuFWAezAZ2',NULL,NULL,'2023-12-10 15:29:09',0,'2023-12-10 15:29:09',0,'ACTIVO',1,'SI','2023-12-10 15:29:09',NULL,NULL,0);
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16 22:40:01
